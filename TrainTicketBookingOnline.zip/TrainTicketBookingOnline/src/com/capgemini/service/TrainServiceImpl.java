package com.capgemini.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;
import com.capgemini.dao.TrainDaoImpl;
import com.capgemini.exception.BookingException;


public class TrainServiceImpl implements TrainService
{
	TrainDaoImpl trainDao=null;
	
	public TrainServiceImpl()
	{
		trainDao = new TrainDaoImpl();
	}

	@Override
	public ArrayList<TrainBean> retrieveTrainDetails() throws BookingException 
	{
		
		return trainDao.retrieveTrainDetails();
	}

	@Override
	public int bookTicket(BookingBean bookingBean) throws BookingException 
	{
		return trainDao.bookTicket(bookingBean);
	}

	@Override
	public boolean validateCustomerId(String custId) throws BookingException 
	{
		String idPattern="[A-Z][0-9][0-9][0-9][0-9][0-9][0-9]";
		if(Pattern.matches(idPattern, custId))
			return true;
			
		else
			throw new BookingException("Inavlid Customer Id");
	}

}
