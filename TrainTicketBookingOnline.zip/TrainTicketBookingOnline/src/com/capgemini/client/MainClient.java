package com.capgemini.client;

import java.util.ArrayList;
import java.util.Scanner;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;
import com.capgemini.exception.BookingException;
import com.capgemini.service.TrainServiceImpl;





public class MainClient 
{
	static TrainServiceImpl trainService=null;
	static Scanner sc=null;
	
	public static void main(String args[])
	{
		trainService=new TrainServiceImpl();
		sc=new Scanner(System.in);
		System.out.println("**** Welcome To Online Train Booking Portal *****");
		int choice=0;
		while(true)
		{
			System.out.println("What do you want to do ?");
			System.out.println("1 : Book Ticket \t2 : Exit ");
			System.out.println("Enter your choice : ");
			choice=sc.nextInt();
			switch(choice)
			{
				case 1:bookTicketsOnline();break;
				default: System.exit(0);
				 
			}
		}
		

	}


	public static void bookTicketsOnline()
	{
		ArrayList<TrainBean> trainList;
		BookingBean bookingBean=null;
		String custId;
		int trainId,noOfSeats;
		try {
			
			trainList = trainService.retrieveTrainDetails();
			System.out.println("\tTRAINID \tTRAINTYPE \tDATE_OF_JOURNEY \tFROM_STOP \tTO_STOP \tAVAILABLE_SEATS \tFARE");
			for(TrainBean tt:trainList)
			{
				System.out.println("\t"+tt.getTrainId()+"\t"+tt.getTrainType()+"\t"+tt.getDateOfJourney()+"\t"+tt.getFromStop()+"\t"+tt.getToStop()+"\t"+tt.getAvailableSeats()+"\t"+tt.getFare());
			}
			
			System.out.println("Enter Customer Id");
			custId=sc.next();
			if(trainService.validateCustomerId(custId))
			{
				System.out.println("Enter train Id");
				trainId=sc.nextInt();
				System.out.println("Enter number of seats");
				noOfSeats=sc.nextInt();
				bookingBean = new BookingBean(0,noOfSeats,trainId,custId);
				int data = trainService.bookTicket(bookingBean);
				
				
					System.out.println("Booking Id : "+data);
				
				
			}
			else
				throw new BookingException("Data not Inserted");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}
}