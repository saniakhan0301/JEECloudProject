package com.capgemini.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;
import com.capgemini.exception.BookingException;
import com.capgemini.util.DBUtil;




public class TrainDaoImpl implements TrainDao
{

	static Logger myLogger=Logger.getLogger(TrainDaoImpl.class);
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	
	@Override
	public ArrayList<TrainBean> retrieveTrainDetails() throws BookingException 
	{
		PropertyConfigurator.configure("log4j.properties");
		ArrayList<TrainBean> trainList=null;
		try {
			trainList=new ArrayList<TrainBean>();
			con=DBUtil.getConn();
			
			String selectqry="SELECT * FROM TrainDetails";
			st=con.createStatement();
			rs=st.executeQuery(selectqry);
			while(rs.next())
			{
				LocalDate date=rs.getDate("dateOfJourney").toLocalDate();
				trainList.add(new TrainBean(rs.getInt("trainId"),rs.getString("trainType"),date,rs.getString("fromStop"),rs.getString("toStop"),rs.getInt("availableSeats"),rs.getInt("fare")));
			}
			
			 myLogger.info("Data Retrieved");
		} 
		catch (Exception e) 
		{
			//e.printStackTrace();
			 myLogger.error("Train details cannot be displayed");
			throw new BookingException("Sorry Details Cannot be Displayed.");
		} 
		finally
		{
			try 
			{
				st.close();
				rs.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				
				throw new BookingException("Sorry Details Cannot be displayed.");

			}
		}
		
		return trainList;
		 

	}

	@Override
	public int bookTicket(BookingBean bookingBean) throws BookingException 
	{
		int data;
		int bookingId=0;
		try 
		{
			PropertyConfigurator.configure("log4j.properties");
			con=DBUtil.getConn();
			String checkquery="SELECT * FROM TrainDetails WHERE trainId=?";
			pst=con.prepareStatement(checkquery);
			pst.setInt(1, bookingBean.getTrainId());
			rs=pst.executeQuery();
			int noOfSeats=0;
			while(rs.next())
			{
				noOfSeats=rs.getInt("availableSeats");
			}
			
			if(  noOfSeats>=bookingBean.getNoOfSeat()) 
			{
				
				String insertqry="INSERT INTO BookingDetails VALUES(Booking_Id_Seq.nextVal,?,?,?)";
				pst=con.prepareStatement(insertqry);
				
				pst.setString(1, bookingBean.getCustId());
				pst.setInt(2, bookingBean.getTrainId());
				pst.setInt(3, bookingBean.getNoOfSeat());
				data=pst.executeUpdate();
				//update mobile table
				String qry="UPDATE TrainDetails SET availableSeats = ? WHERE trainId=?";
				pst=con.prepareStatement(qry);
				noOfSeats-=bookingBean.getNoOfSeat();
			    pst.setInt(1, noOfSeats);
			    pst.setInt(2, bookingBean.getTrainId());
			    int noOfRecAffected=pst.executeUpdate();
			    //System.out.println(noOfRecAffected+" Booking detail inserted.");
			    
			    
				 String qry1="SELECT  * FROM BOOKINGDETAILS WHERE custId=?";
					pst=con.prepareStatement(qry1);
					
				    pst.setString(1, bookingBean.getCustId());
				    rs=pst.executeQuery();
					
					while(rs.next())
					{
						bookingId=rs.getInt("bookingId");
					}
					
					bookingBean.setBookingId(bookingId);
					 myLogger.info("Booking Details"+bookingBean);
				 
			   
			}
			else 
				throw new BookingException("No Seats Available");
		} 
		catch (Exception e) 
		{
			//e.printStackTrace();
			 myLogger.error("Customer Detail Not Inserted: ");
			throw new BookingException("No Seats Available");
		}
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				
				throw new BookingException(e.getMessage());

			}
		}
		
		return bookingId;
		
		
		
		
	
	}
	
}
