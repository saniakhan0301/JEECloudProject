package com.capgemini.dao;
import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;
import com.capgemini.exception.BookingException;

import java.util.ArrayList;

public interface TrainDao 
{
	public ArrayList<TrainBean> retrieveTrainDetails() throws BookingException;
	public int bookTicket(BookingBean bookingBean) throws BookingException;
}
