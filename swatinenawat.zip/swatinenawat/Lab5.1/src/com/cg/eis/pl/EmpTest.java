package com.cg.eis.pl;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;
import com.cg.eis.exception.ExceptionCheck;

import junit.framework.Assert;

public class EmpTest {
	
	static ExceptionCheck emp=null;
	@BeforeClass
	public static void setUp()
	{
		emp=new ExceptionCheck();
		System.out.println("setUp is call once "+" Before the execution of "+"all test cases ");
		
		
	}
	@AfterClass
	public static void tearDown()
	{
		System.out.println("tearDown is call once "+" After the execution of "+"each test cases ");

	}
	@Before
	public  void init()
	{
		System.out.println("init is call once "+" Before the execution of "+"each test cases ");

	}
	@After
	public void detroy()
	{
		System.out.println("detroy is call once "+" After the execution of "+"each test cases ");

	}
	@Test
	public void testErrorCheck()
	{
		Assert.assertEquals("Executed",emp.checkSalary(200));
	}
	

}
