package com.cg.eis.pl;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;
import com.cg.eis.service.EmployeeInsuranceSystem;

public class EmployeeMain {
	EmployeeException ex=new EmployeeException();
	public static void main(String args[])
	{
		
		int id;
		double salary;
		Scanner sc=new Scanner(System.in);
		HashMap<Integer,Employee> emp=new HashMap<Integer,Employee>();
		try {
			System.out.println("Enter total no.of employess");
			int count=sc.nextInt();
			EmployeeInsuranceSystem eis=new EmployeeInsuranceSystem();
			for(int i=0;i<count;i++)
			{
			System.out.println("Enter id");
			id=sc.nextInt();
			System.out.println("Enter name");
			String n=sc.next();
			System.out.println("Enter salary");
			salary=sc.nextDouble();
			
			if(salary<3000)
				throw new EmployeeException();
			System.out.println("Enter designation");
			String des=sc.next();
			
			
			Employee e=new Employee(id,n,salary,des);
			// e.display();
			emp.put(id,e);
			
			eis.empObject(e);
			}
			eis.empObjectDeserialize();
			
			
			System.out.println("******Database Records*******");
			Employee e1=new Employee();
			e1.displayDatabase();
			System.out.println("*************");
			System.out.println(""); 
			System.out.println(""); 
			
			
			
			
			System.out.println("******Delete Records*******");
			System.out.println("enter id:");
			int emp_id1=sc.nextInt();
			e1.deleteDatabase(emp_id1);
			System.out.println("*************");
			
			
			System.out.println("Enter Insurance scheme A or B:");
			String ins=sc.next();
			Set<Map.Entry<Integer,Employee>> mapset=emp.entrySet();
			Iterator<Map.Entry<Integer,Employee>> it=mapset.iterator();
			while(it.hasNext())
			{
				Map.Entry<Integer,Employee> entry =it.next();
				if(entry.getValue().insuranceScheme.equals(ins)) {
					System.out.println("Id : "+entry.getValue().id+" Name : "+entry.getValue().name+" Salary : "+entry.getValue().salary+" Designation : "+entry.getValue().designation+" Insurance scheme : "+entry.getValue().insuranceScheme);
				}
			   // System.out.println("Key : "+entry.getKey()+" Name : "+entry.getValue());
			}
			//System.out.println(emp);
			
			
			
			
			
			
			System.out.println("Enter employee Id to remove:");
			int rem=sc.nextInt();
			emp.remove(rem);
			System.out.println(emp);
			System.out.println("*****Sorted List*******");
			Collection<Employee> empSet=emp.values();
			Iterator<Employee> empIt=empSet.iterator();
			ArrayList<Employee> empArray=new ArrayList<Employee>();
			
			while(empIt.hasNext())
			{
				empArray.add(empIt.next());
				//System.out.println("Id : "+empIt.next().id+" Name : "+empIt.next().name+" Salary : "+empIt.next().salary+" Designation : "+empIt.next().designation+" Insurance scheme : "+empIt.next().insuranceScheme);
			}
			empArray.sort(null);
			Iterator<Employee> empIt1=empArray.iterator();
			// System.out.println(empArray);
			while(empIt1.hasNext())
			{
				empIt1.next().display();
				//System.out.println("Id : "+empIt1.next().id+" Name : "+empIt1.next().name+" Salary : "+empIt1.next().salary+" Designation : "+empIt1.next().designation+" Insurance scheme : "+empIt1.next().insuranceScheme);
			}
		}
		catch(EmployeeException e)
		{
			System.out.println(e);
		}
		finally {
			sc.close();
			}
		
	}
	
	
	
	

}
