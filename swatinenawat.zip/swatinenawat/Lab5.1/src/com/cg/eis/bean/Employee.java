
package com.cg.eis.bean;
import java.util.Scanner;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
import com.cg.eis.exception.*;


public class Employee implements Comparable<Employee>,Serializable{

	/**
	 * 
	 */
	
	
	
	public int id;
	public String name;
	public double salary;
	public String designation;
	 public String insuranceScheme;
	 public Employee() {}
	public Employee(int id,String name,double salary,String designation)
	{
		this.id=id;
		this.name=name;
		this.salary=salary;
		this.designation=designation;
		if(designation.equals("System Associate")&&salary>=5000&&salary<20000)
		{
			this.insuranceScheme="C";
		}
		if(designation.equals("Programmer")&&salary>=20000&&salary<40000)
		{
			this.insuranceScheme="B";
		}
		else if(designation.equals("Manager")&&salary>=40000)
		{
			this.insuranceScheme="A";
		}
		else
			this.insuranceScheme="No Scheme";
		
		
		String qry="INSERT INTO emp_lab VALUES(?,?,?,?,?)";
		
        Connection con=null;
        PreparedStatement pst=null;
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G","lab1btrg4","lab1boracle");
		    pst=con.prepareStatement(qry);
		    pst.setInt(1, this.id);
		    pst.setString(2, this.name);
		    pst.setInt(3, (int)this.salary);
		    pst.setString(4, this.designation);
		    pst.setString(5, this.insuranceScheme);
		    int noOfRecAffected=pst.executeUpdate();
		  System.out.println(noOfRecAffected+" Data is inserted in the table");
		} 
		catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}
		
		
		
		
		
		
		
		
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + ", designation=" + designation
				+ ", insuranceScheme=" + insuranceScheme + "]";
	}
	public void display()
	{
		System.out.println("Id: "+id);
		System.out.println("Name: "+name);
		System.out.println("Salary: "+salary);
		System.out.println("Designation: "+designation);
		System.out.println("Insurance Scheme: "+insuranceScheme);
	}
	public void displayDatabase()
	{
		
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G","lab1btrg4","lab1boracle");
		    st=con.createStatement();
		    rs=st.executeQuery("SELECT * FROM emp_lab");
		    while(rs.next())
		    {

		    System.out.println(" : "+rs.getInt("emp_id")+" : "+rs.getString("emp_name")+" : "+rs.getInt("emp_sal")+" : "+rs.getString("emp_desig")+" : "+rs.getString("emp_insurance"));
		    }
		} 
		catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}
		
	}
	
	
	public void deleteDatabase(int id)
	{
		
		
		
		String qry="DELETE FROM emp_lab where emp_id=?";
		
        Connection con=null;
        PreparedStatement pst=null;
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G","lab1btrg4","lab1boracle");
		    pst=con.prepareStatement(qry);
		    pst.setInt(1, id);
		    int noOfRecAffected=pst.executeUpdate();
		    System.out.println(noOfRecAffected+" Data is deleted from the table");
		} 
		catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}



		
		
		
	}
	
	
	@Override
	public int compareTo(Employee ee)
	{
	if(this.salary<ee.salary)
		{
			return -1;
		}
		else if(this.salary==ee.salary)
		{
			return 0;
		}
		return 1;
	}
	/*@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + ", designation=" + designation
				+ ", insuranceScheme=" + insuranceScheme + "]";
	}*/
	
	
}
