package com.cg.eis.exception;



public class ExceptionCheck {
	//EmployeeException ex=new EmployeeException();
	public ExceptionCheck() {}
	public String checkSalary(int sal)
	{
		try {
		if(sal<3000)
			throw new EmployeeException();
		}
		catch(EmployeeException e)
		{
			System.out.println(e);
			return "Executed";
		}
		return "Executed";
	}
	
}
