
package com.cg.eis.exception;

public class EmployeeException extends Exception {



	public String toString()
	{
		return "Salary is below 3000";
	}
	
}
