package com.cg.eis.service;


import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.cg.eis.bean.Employee;

interface EmployeeService {
	void serviceOffered(String d);
	
}


public class EmployeeInsuranceSystem implements EmployeeService {
	public void serviceOffered(String d)
	{
		if(d.equals("A"))
		{
			System.out.println("Medical");
		}
		else
			System.out.println("Education");
	}
	public void empObject(Employee ee)
	{
		FileOutputStream fos=null;
		ObjectOutputStream oos=null;
		
		try {
	          fos=new FileOutputStream("EmployeeDetails.obj",true);
			  oos=new ObjectOutputStream(fos);
			  oos.writeObject(ee);
			 
			  System.out.println("Emp ee is written in the file.");
		} 
		catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	
	public void empObjectDeserialize()
	{
		FileInputStream fis=null;
		ObjectInputStream ois=null;
		try {
			fis=new FileInputStream("EmployeeDetails.obj");
			
			
	   
		while(fis.available()>0) {
			
			    ois=new ObjectInputStream(fis);
				Employee ee=(Employee) ois.readObject();
				//System.out.println(ee);
				System.out.println("employee Info from file : Id: "+ee.id+" Name: "+ee.name+" Salary: "+ee.salary+" Designation: "+ee.designation);	
			
		
		}
				
	        
		
			}
		
		catch (IOException | ClassNotFoundException e) {
			
			e.printStackTrace();
		}
		
	}
}
