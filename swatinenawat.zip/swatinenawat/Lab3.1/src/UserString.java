import java.util.Scanner;

public class UserString {
	
	public static void main(String args[])
	{
		String str;
		int choice;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter String");
		str=sc.nextLine();
		System.out.println("1: Add the String to itself");
		System.out.println("2: Replace odd positions with #");
		System.out.println("3: Remove duplicate characters in the String");
		System.out.println("4: Change odd characters to upper case");
		System.out.println("Enter your choice");
		choice=sc.nextInt();
		char[] chars=str.toCharArray();
		int len=str.length();
	    switch(choice)
	    {
	    case 1: str=str+str;System.out.println(str);break;
	    case 2: 
	            String str1="";
	            
	            for(int i=0;i<len;i++)
	    		{
	    	    	if(i%2==0)
	    	    		str1=str1+"#";
	    	    	else
	    	    		str1=str1+chars[i];
	    	    	
	                	
	    		}
	    	    System.out.println(str1);break;
	    case 3: String str2="";
				for(int i=0;i<len;i++)
			    {
					    int l=str2.length(),j=0;
					    char c;
				    	while(j!=l)
				    	{
				    		c=str2.charAt(j);
				    		if(chars[i]==c)
				    		{
				    	
				    			break;
				    		}
				    		j++;
				    	}
				    	if(j==l)
				    		str2=str2+chars[i];
			            	
			   }
			   System.out.println(str2);break;
	    case 4:String str3="";
        
		        for(int i=0;i<len;i++)
				{
			    	if(i%2==0)
			    	{
			    		
			    		str3=str3+Character.toUpperCase(chars[i]);
			    	}
			    		
			    	else
			    		str3=str3+chars[i];
			    	
		            	
				}
			    System.out.println(str3);break;
	    default: System.out.println("Invalid Input");
	    }
        
		
	}
	

}
