import java.util.Scanner;

public class PositiveString {

	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter string: ");
		String str=sc.nextLine();
		PositiveString s=new PositiveString();
		s.positiveCheck(str);
	}
	public void positiveCheck(String str)
	{
		int len=str.length();
		int asc=1;
		char[] chars=str.toCharArray();
		int i;
		for(i=0;i<len;i++)
		{
			int ascNow=(int)chars[i];
			if(i==0)
				asc=ascNow;
			else
			{
				if(asc>ascNow)
					break;
			}
		}
		if(i==len)
			System.out.println("Positive");
		else
			System.out.println("Negative");
	}
	
	
}
