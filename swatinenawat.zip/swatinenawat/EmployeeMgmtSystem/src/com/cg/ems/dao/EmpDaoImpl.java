package com.cg.ems.dao;

import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import java.io.IOException;
import java.sql.*;
import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DBUtil;

public class EmpDaoImpl implements EmpDao
{
    Logger daoLogger=null;
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	
	public EmpDaoImpl() {
		daoLogger=Logger.getLogger(EmpDaoImpl.class);
		PropertyConfigurator.configure("resources/log4j.properties");
	}

	@Override
	public ArrayList<Employee> getAllEmp() throws EmployeeException 
	{
		ArrayList<Employee> empList=null;
		try {
			empList=new ArrayList<Employee>();
			con=DBUtil.getConn();
			
			String selectqry="SELECT * FROM emp_157794";
			st=con.createStatement();
			rs=st.executeQuery(selectqry);
			while(rs.next())
			{
				
				empList.add(new Employee(rs.getInt("emp_id"),rs.getString("emp_name"),rs.getFloat("emp_sal")));
			}
			
			
		} 
		catch (Exception e) 
		{
			throw new EmployeeException(e.getMessage());
		} 
		finally
		{
			try 
			{
				st.close();
				rs.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				daoLogger.error(e.getMessage());
				throw new EmployeeException(e.getMessage());

			}
		}
		daoLogger.info("All data Retrived: "+empList);
		return empList;
	}

	@Override
	public int addEmp(Employee ee) throws EmployeeException
	{
		int data;
		try 
		{
			con=DBUtil.getConn();
			String insertqry="INSERT INTO emp_157794 VALUES(?,?,?)";
			pst=con.prepareStatement(insertqry);
			pst.setInt(1, ee.getEmpId());
			pst.setString(2, ee.getEmpName());
			pst.setFloat(3, ee.getEmpSal());
			data=pst.executeUpdate();
			
		
		} 
		catch (Exception e) {
			
			throw new EmployeeException(e.getMessage());
		}
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				daoLogger.error(e.getMessage());
				throw new EmployeeException(e.getMessage());

			}
		}
		daoLogger.info("Data is inserted : "+ee);
		return data;
		
	}
	
}
