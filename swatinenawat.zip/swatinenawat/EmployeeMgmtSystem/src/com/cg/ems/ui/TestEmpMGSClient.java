package com.cg.ems.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.EmpService;
import com.cg.ems.service.EmpServiceImpl;

public class TestEmpMGSClient 
{
	static EmpServiceImpl empService=null;
	static Scanner sc=null;
	public static void main(String[] args)
	{
		empService=new EmpServiceImpl();
		sc=new Scanner(System.in);
		System.out.println("**** Welcome To EMS *****");
		int choice=0;
		while(true)
		{
			System.out.println("What do you want to do ?");
			System.out.println("1 : Add EMP\t2 : Show All Emp\t"+"3 : Update EMP\t4 : Delete Emp\t5 : Exit");
			System.out.println("Enter your choice : ");
			choice=sc.nextInt();
			switch(choice)
			{
				case 1:insertEmp();break;
				case 2:dispAllEmp();break;
				default: System.exit(0);
				 
			}
		}
		

	}
	private static void dispAllEmp() {
		ArrayList<Employee> empList;
		try {
			empList = empService.getAllEmp();
			System.out.println("\tEMPID \tEMPNAME \tEMPSAL");
			for(Employee ee:empList)
			{
				System.out.println("\t"+ee.getEmpId()+"\t"+ee.getEmpName()+"\t"+ee.getEmpSal());
			}
		} 
		catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	private static void insertEmp() {
		int id,dataInserted;
		String name;
		float sal;
		
		try 
		{
			sc=new Scanner(System.in);
			System.out.println("Enter emp id:");
			id=sc.nextInt();
			System.out.println("Enter emp name:");
			name=sc.next();
			if(empService.validateEmpName(name))
			{
				System.out.println("Enter emp salary:");
				sal=sc.nextFloat();
				Employee ee=new Employee(id,name,sal);
				dataInserted=empService.addEmp(ee);
				if(dataInserted==1)
				{
					dispAllEmp();
				}
				else
					System.out.println("Sorry data is not inserted.");
			}
			
			
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
