package com.cg.synch.demos;

public class Resource {
		private int data;
		boolean dataAvailable=false;
		
		synchronized void insert(int data)
		{
			if(dataAvailable)
			{
				try {
					wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			else
			{
				this.data=data;
				dataAvailable=true;
				System.out.println("Data Inserted : "+data);
				notify();
			}
			
				
		}
		synchronized int retrive()
		{
			if(!dataAvailable)
			{
				try {
					wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			System.out.println("Retrived .. "+data);	
		    dataAvailable=false;
		   
			return this.data;
			
		}
		
	

}
