package com.capgemini.exception;

public class BookingException extends Exception
{
	String msg;

	public BookingException(String msg) {
		super();
		this.msg = msg;
		System.out.println(msg);
	}
	
	
}
