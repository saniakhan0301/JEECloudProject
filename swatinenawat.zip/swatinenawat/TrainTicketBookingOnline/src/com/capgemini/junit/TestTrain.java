package com.capgemini.junit;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.bean.BookingBean;
import com.capgemini.dao.TrainDaoImpl;
import com.capgemini.exception.BookingException;
import com.capgemini.service.TrainServiceImpl;

import junit.framework.Assert;

public class TestTrain 
{
	static TrainDaoImpl train=null;
	static BookingBean bookingBean=null;
	
	
	@BeforeClass
	public static void setUp()
	{
		train=new TrainDaoImpl();
		//bookingBean=new BookingBean(0,3,3,"C333333");
		System.out.println("setUp is call once "+" Before the execution of "+"all test cases ");
		
		
	}
	@AfterClass
	public static void tearDown()
	{
		System.out.println("tearDown is call once "+" After the execution of "+"each test cases ");

	}
	@Before
	public  void init()
	{
		System.out.println("init is call once "+" Before the execution of "+"each test cases ");

	}
	@After
	public void detroy()
	{
		System.out.println("detroy is call once "+" After the execution of "+"each test cases ");

	}

	@Test

	public void bookTicket()
	{
		
			try {
				
				Assert.assertEquals(1008,train.bookTicket(new BookingBean(0,2,1,"D444444")));
			} catch (BookingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
	
	}

