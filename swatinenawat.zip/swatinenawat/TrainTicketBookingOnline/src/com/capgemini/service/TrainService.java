package com.capgemini.service;

import java.util.ArrayList;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;
import com.capgemini.exception.BookingException;

public interface TrainService 
{
	public ArrayList<TrainBean>retrieveTrainDetails()throws BookingException;
	public int bookTicket(BookingBean bookingBean)throws BookingException;
	public boolean validateCustomerId(String custId)throws BookingException;
}
