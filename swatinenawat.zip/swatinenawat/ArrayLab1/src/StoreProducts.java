import java.util.Arrays;
import java.util.Scanner;

public class StoreProducts {

	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter total numbers of product: ");
		int total=sc.nextInt();
		String storeProducts[]=new String[total];
		System.out.println("Enter products names:");
		for(int i=0;i<storeProducts.length;i++)
		{
			storeProducts[i]=sc.next();
		}
		Arrays.sort(storeProducts);
		for(int i=0;i<storeProducts.length;i++)
		{
			System.out.println(storeProducts[i]);
		}
		sc.close();
	}
	
	
}
