import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;
public class StoreProductList {


	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter total numbers of product: ");
		int total=sc.nextInt();
		ArrayList<String> storeProducts=new ArrayList<String>();
		System.out.println("Enter products names:");
		for(int i=0;i<total;i++)
		{
			storeProducts.add(sc.next());
		}
		storeProducts.sort(null);
		for(String a : storeProducts)
		{
			System.out.println(a);
		}
		sc.close();
	}
	
}
