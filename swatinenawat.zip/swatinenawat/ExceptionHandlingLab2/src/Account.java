import java.util.Random;

 abstract public class Account{
	Person accHolder;
	long accNum;
	double balance;
	Account(){}
	Account(double b,Person p)
	{
		Random r=new Random();
		this.accNum=(int)(r.nextInt());
		this.balance=b;
		accHolder=new Person();
		accHolder.name=p.name;
		try
		{
			if(p.age<15) {
				throw new MyException();
		}
			accHolder.age=p.age;
	}
			catch(MyException e)
			{
				System.out.println(e);
			}
			
		
		   
	}
	public void setAccNum(long accNum)
	{
		this.accNum=accNum;
	}
	
	public long getAccNum()
	{
		return this.accNum;
	}
	
	public void deposit(double d)
	{
		this.balance+=d;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	abstract public boolean withdraw(double d);
	
		
	
}
