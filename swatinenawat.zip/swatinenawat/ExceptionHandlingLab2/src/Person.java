
class Person{
	String name;
	float age;
	Person(){}
	Person(String n,float b)
	{
		
		name=n;
		age=b;
	}
	public void setName(String name)
	{
		this.name=name;
	}
	public void setAge(float age)
	{
		this.age=age;
	}
    public String getName()
    {
    	return this.name;
    }
    public float getAge()
    {
    	return this.age;
    }
}
