
public class AccountMain {
	public static void main(String args[]) {
	
		Person p=new Person("smith",26);
		Person p1=new Person("katty",12);
		Account a=new SavingsAccount(2000,p);
		Account a1=new SavingsAccount(3000,p1);
		a.deposit(2000);
		System.out.println("Katty withdrawl successfull: "+a1.withdraw(1000));
        System.out.println("Smith balance: "+a.getBalance());
        System.out.println("Katty balance: "+a1.getBalance());
        
	
	
}
}
