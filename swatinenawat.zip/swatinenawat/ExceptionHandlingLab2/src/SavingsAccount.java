
public class SavingsAccount extends Account{

	
	final double MINIMUMBALANCE=500;
	public boolean withdraw(double d)
	{
		if(balance-d>=MINIMUMBALANCE)
		{
			balance-=d;
			return true;
		}
		return false;
	}
	public SavingsAccount() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SavingsAccount(double b, Person p) {
		super(b, p);
		// TODO Auto-generated constructor stub
	}
}
