@FunctionalInterface
public interface PowerMethod 
{
	public double power(double a,double b);
}
