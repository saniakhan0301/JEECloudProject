
public class lab2 
{
	public static void main(String args[])
	{
		StrMethod str=(a)->a.replace("", " ");
		System.out.println("string : "+str.method1("HELLO"));
	}
}
