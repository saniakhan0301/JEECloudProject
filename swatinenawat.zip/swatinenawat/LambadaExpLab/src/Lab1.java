
public class Lab1 
{
	public static void main(String[] args) 
	{
		PowerMethod pm=(a,b)->Math.pow(a, b);
		System.out.println("Greatest Number Is : "+pm.power(2, 4));
	}

	
	

}
