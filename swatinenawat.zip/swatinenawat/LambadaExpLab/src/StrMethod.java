@FunctionalInterface
public interface StrMethod {

	public String method1(String a);
}
