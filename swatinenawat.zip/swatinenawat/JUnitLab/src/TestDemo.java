import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import junit.framework.Assert;

public class TestDemo {

	static Date d=null;
	@BeforeClass
	public static void setUp()
	{
		d=new Date(24,12,1996);
		System.out.println("setUp is call once "+" Before the execution of "+"all test cases ");
		
		
	}
	@AfterClass
	public static void tearDown()
	{
		System.out.println("tearDown is call once "+" After the execution of "+"each test cases ");

	}
	@Before
	public  void init()
	{
		System.out.println("init is call once "+" Before the execution of "+"each test cases ");

	}
	@After
	public void detroy()
	{
		System.out.println("detroy is call once "+" After the execution of "+"each test cases ");

	}
	@Test
	public void testget1()
	{
		Assert.assertEquals(24,d.getDay());
	}
	@Test
	@Ignore
	public void testget2()
	{
		Assert.assertEquals(12,d.getMonth());
	}
	@Test
	public void testget3()
	{
		Assert.assertEquals(1996,d.getYear());
	}
}
