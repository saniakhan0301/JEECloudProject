import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import java.time.Period;
public class DateDurationLab {

	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		LocalDate currentDate = LocalDate.now();
		System.out.println("Enter date: ");
		String userDate=sc.nextLine();
		DateTimeFormatter formatter= DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate enteredDate=LocalDate.parse(userDate,formatter); 
		
		Period period=enteredDate.until(currentDate);
		System.out.println("No. of days: "+period.getDays());
		System.out.println("No. of Months: "+period.getMonths());
		System.out.println("No. of years: "+period.getYears());
	}
	
	
	
}
