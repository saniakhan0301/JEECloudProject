import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class TestTreeSetEmpDemo {

	
	public static void main(String args[])
	{
		TreeSet<Person> empList= new TreeSet<Person>();
		Person p1=new Person(112081,"Swati",1000.0f);
		Person p2=new Person(112082,"neha",2000.0f);
		Person p3=new Person(112080,"meghna",3000.0f);
		Person p4=new Person(112084,"amruta",4000.0f);
		Person p5=new Person(112084,"amruta",4000.0f);
		empList.add(p1);
		empList.add(p2);
		empList.add(p3);
		empList.add(p4);
		empList.add(p5);
		Iterator<Person> itEmp=empList.iterator();
	
		while(itEmp.hasNext())
		{
			System.out.println("...."+(itEmp.next()).empId);
			
		}

	}
}
