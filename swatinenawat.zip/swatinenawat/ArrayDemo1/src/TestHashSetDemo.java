import java.util.ArrayList;
import java.util.Iterator;
import java.util.*;
public class TestHashSetDemo {
	public static void main(String args[])
	{
		HashSet<Integer> intList= new HashSet<Integer>(4);
		Integer i1=new Integer(10);
		Integer i2=new Integer(20);
		Integer i3=new Integer(30);
		Integer i4=new Integer(20);
		intList.add(i1);
		intList.add(i2);
		intList.add(i3);
		intList.add(i4);
		Iterator<Integer> itEmp=intList.iterator();
		while(itEmp.hasNext())
		{
			System.out.println("...."+itEmp.next());
		}

	}

}
