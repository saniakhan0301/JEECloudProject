import java.util.ArrayList;


import java.util.*;
public class TestArrayListDemo {



	
	
public static void main(String args[])
{
	ArrayList<Person> empList=new ArrayList<Person>();
	Person p1=new Person(112081,"Swati",1000.0f);
	Person p2=new Person(112082,"neha",2000.0f);
	Person p3=new Person(112083,"meghna",3000.0f);
	Person p4=new Person(112084,"amruta",4000.0f);
	empList.add(p1);
	empList.add(p2);
	empList.add(p3);
	empList.add(p4);
	Iterator<Person> itEmp=empList.iterator();
	while(itEmp.hasNext())
	{
		System.out.println("...."+itEmp.next());
	}

}



	
}
