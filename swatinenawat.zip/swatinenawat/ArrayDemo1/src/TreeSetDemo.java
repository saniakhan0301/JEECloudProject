import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetDemo {

	public static void main(String args[])
	{
		TreeSet<Integer> intList= new TreeSet<Integer>();
		Integer i1=new Integer(40);
		Integer i2=new Integer(20);
		Integer i3=new Integer(30);
		Integer i4=new Integer(20);
		intList.add(i1);
		intList.add(i2);
		intList.add(i3);
		intList.add(i4);
		Iterator<Integer> itEmp=intList.iterator();
		while(itEmp.hasNext())
		{
			System.out.println("...."+itEmp.next());
		}

	}
	
	
}
