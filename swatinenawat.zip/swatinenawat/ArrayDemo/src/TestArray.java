import java.util.*;
public class TestArray {

	public static void main(String args[])
	{
		int marks[]=new int[3];
		marks[0]=90;
		marks[1]=100;
		marks[2]=99;
		for(int i=0;i<marks.length;i++)
		{
			System.out.println("Marks["+i+"] : "+marks[i]);
		}
		Scanner sc=new Scanner(System.in);
		System.out.println("How many Emp Do you want?");
		int empCount=sc.nextInt();
		Person emps[]=new Person[empCount];
		for(int i=0;i<emps.length;i++)
		{
			System.out.println("Enter Id");
			int a=sc.nextInt();
			System.out.println("Enter Name");
			String b=sc.next();
			System.out.println("Enter Salary");
			float c=sc.nextFloat();
			Person p=new Person(a,b,c);
			emps[i]=p;
		}
		for(Person temp:emps)
		{
			System.out.println(temp);
		}
	}
	
	
	
}
