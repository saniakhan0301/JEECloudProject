
public class TestVarArgsDemo {

	public int add(int ...nums)
	{
		int sum=0;
		for(int j:nums)
		{
			sum+=j;
		}
		return sum;
	}
	
	public static void main(String args[])
	{
		TestVarArgsDemo obj1=new TestVarArgsDemo();
		System.out.println("Addition of Numbers: "+ obj1.add(7, 8,10,100));
		
	}
}
