
public class HelloWorld {
	public String say()
	{
		return("HelloWorld!");
	}

}
