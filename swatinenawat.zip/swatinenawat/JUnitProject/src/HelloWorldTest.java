import org.junit.Test;
import static org.junit.Assert.*;
public class HelloWorldTest {
	
	@Test
	public void testSay()
	{
		HelloWorld hello=new HelloWorld();
		assertEquals("Unexpected Result ","Hello World!",hello.say());
	}
	

}
