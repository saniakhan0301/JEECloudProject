import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;
//Stream works only for collections
public class TeststreamAPIDemo {

	public static void main(String[] args) 
	{
		List<Integer> intList=Arrays.asList(45,8,10,3,89,456,10,45);
		Stream<Integer> intListStream=intList.stream();
		intListStream.filter((num)->num>10).
		forEach(num->System.out.println(num));
		
		System.out.println("***************Print Distinct*********************");
		
		intList.stream().distinct().forEach(num->System.out.print(" : "+num));
		System.out.println();
		intList.stream().distinct().forEach(System.out::println);   //method reference syntax to eliminate duplicates

		System.out.println("***************Print Length*********************");
		List<String> cityList=Arrays.asList("Pune","","Mumbai","Delhi","Noida","");
		cityList.stream().map(str->str.length()).forEach(System.out::println);
	
		System.out.println("************************************");
		long countOfEmptyString=cityList.stream().filter(str->str.isEmpty()).count();
		System.out.println("How many empty string ? "+countOfEmptyString);
	}

}
