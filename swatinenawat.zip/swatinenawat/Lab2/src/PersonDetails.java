import java.util.Scanner;

public class PersonDetails {

	public static void main(String args[])
	{
		String firstName,lastName;
		String gender;
		int age;
		float weight;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter First Name: ");
		firstName=sc.next();
		System.out.println("Enter Last Name: ");
		lastName=sc.next();
		System.out.println("Enter Gender: ");
		gender=sc.next();
		System.out.println("Enter Age: ");
		age=sc.nextInt();
		System.out.println("Enter Weight: ");
		weight=sc.nextFloat();
		System.out.println("Person Details:");
		System.out.println("");
		System.out.println("------------------------");
		System.out.println("First Name: "+firstName);
		System.out.println("Last Name: "+lastName);
		System.out.println("Gender: "+gender);
		System.out.println("Age: "+age);
		System.out.println("Weight: "+weight);
		
	}
	
	
}
