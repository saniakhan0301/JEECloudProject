

public class PositiveNegative {
	public static void main(String args[])
	{
		int num;
		num=Integer.parseInt(args[0]);
		if(num<0)
			System.out.println("Negative");
		else
			System.out.println("Positive");
		
	}

}
