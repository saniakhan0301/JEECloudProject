import java.io.*;

public class TestEmpDeserDemo {

	public static void main(String args[])
	{
		FileInputStream fis=null;
		ObjectInputStream ois=null;
		try {
			fis=new FileInputStream("EmpObjs.obj");
			ois=new ObjectInputStream(fis);
			Employee ee=(Employee)ois.readObject();
	        System.out.println("employee Info from file : "+ee);	
		}
		
		catch (IOException | ClassNotFoundException e) {
			
			e.printStackTrace();
		}
		
	}
	
}
