import java.io.*;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

public class TestPropFileDemo {

	public static void main(String[] args) {
		
		FileInputStream fis=null;
		Properties myProps=null;
		try {
			
			fis=new FileInputStream("UserInfo.properties");
		    myProps=new Properties();
		    myProps.load(fis);
		    String unm=myProps.getProperty("userid");
		    String pwd=myProps.getProperty("password");
		    System.out.println("Credentials : "+unm+" : "+pwd);
		    System.out.println("********************************");
		    
		    //If we don't know key name
		    
		   Set<Object> ks=myProps.keySet();
		   Iterator it=ks.iterator();
		   while(it.hasNext())
		   {
			   System.out.print(" : "+it.next());
		   }
			   
		   
		   
		} 
		catch (IOException e) {
		
			e.printStackTrace();
		}
		
		
	}

}
