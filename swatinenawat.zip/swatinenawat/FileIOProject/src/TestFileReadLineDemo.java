import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.*;
public class TestFileReadLineDemo {
	
public static void main(String[] args) {
		
		File myFile=new File("C://swatinenawat/FileIOProject/src/TestEmpReadDemo.java");
		FileReader fr=null;
		FileWriter fw=null; 
		BufferedReader br=null;
		BufferedWriter bw=null;
		try {
			fr=new FileReader(myFile);
			br=new BufferedReader(fr);
			fw=new FileWriter("MyFile.txt");
			bw=new BufferedWriter(fw);
			String line=br.readLine();  //reads First byte value
			while(line!=null)       // reads till end of file
			{
				System.out.println(line);
				bw.write(line);
				bw.write("\n");
				bw.flush();
				line=br.readLine();
			}
		}
		catch (IOException e) {
			
			e.printStackTrace();
		}
		

	}
	
	

}
