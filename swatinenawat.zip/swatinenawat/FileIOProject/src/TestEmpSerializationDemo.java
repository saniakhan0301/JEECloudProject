import java.io.*;
import java.util.Scanner;

public class TestEmpSerializationDemo {
	/**
	 * 
	 */


	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Emp Id:");
		int eid=sc.nextInt();
		System.out.println("Enter Emp Name:");
		String ename=sc.next();
		System.out.println("Enter Emp Salary:");
		float esal=sc.nextFloat();
		FileOutputStream fos=null;
		ObjectOutputStream oos=null;
		Employee e1=new Employee(eid,ename,esal);
		try {
	          fos=new FileOutputStream("EmpObjs.obj");
			  oos=new ObjectOutputStream(fos);
			  oos.writeObject(e1);
			  System.out.println("Emp e1 is written in the file.");
		} 
		catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}

}
