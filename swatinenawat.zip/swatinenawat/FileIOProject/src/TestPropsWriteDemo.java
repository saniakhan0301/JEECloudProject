import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.Properties;
import java.io.*;

public class TestPropsWriteDemo {

	public static void main(String[] args) {
		FileOutputStream fos=null;
		Properties myDbInfo=null;
		try {
			fos=new FileOutputStream("dbInfo.properties");
			myDbInfo=new Properties();
			myDbInfo.setProperty("dbUser", "System");
			myDbInfo.setProperty("dbPwd", "Root");
			myDbInfo.store(fos,"This Is Data Base Information");
			System.out.println("Data is written in the file.");
		} 
		catch (IOException e) {
			
			e.printStackTrace();
		}
		

	}

}
