import java.io.*;
import java.util.Scanner;

public class TestEmpInfoDemo {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Emp Id:");
		int eid=sc.nextInt();
		System.out.println("Enter Emp Name:");
		String ename=sc.next();
		System.out.println("Enter Emp Salary:");
		float esal=sc.nextFloat();
		FileOutputStream fos=null;
		DataOutputStream dos=null;
		try {
		      
			fos=new FileOutputStream("EmpInfo.txt");
		    dos=new DataOutputStream(fos);
		    dos.writeInt(eid);
		    dos.writeUTF(ename);
		    dos.writeFloat(esal);
		    System.out.println("All info is been written in the file.");
		      
		      
		} 
		catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}

}
