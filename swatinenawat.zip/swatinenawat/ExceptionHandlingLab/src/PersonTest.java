import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import junit.framework.Assert;

public class PersonTest {

	static Person p=null;
	@BeforeClass
	public static void setUp()
	{
		p=new Person("Swati","Nenawat","F",0123456,21);
		System.out.println("setUp is call once "+" Before the execution of "+"all test cases ");
		
		
	}
	@AfterClass
	public static void tearDown()
	{
		System.out.println("tearDown is call once "+" After the execution of "+"each test cases ");

	}
	@Before
	public  void init()
	{
		System.out.println("init is call once "+" Before the execution of "+"each test cases ");

	}
	@After
	public void detroy()
	{
		System.out.println("detroy is call once "+" After the execution of "+"each test cases ");

	}
	@Test
	public void testPerson1()
	{
		Assert.assertEquals("Swati",p.getFirstName());
	}
	@Test
	
	public void testPerson2()
	{
		Assert.assertEquals("Nenawat",p.getLastName());
	}
	@Test
	public void testPerson3()
	{
		Assert.assertEquals(21,p.getAge());
	}
	@Test
	public void testPerson4()
	{
		Assert.assertEquals("F",p.getGender());
	}
	@Test
	public void testPerson5()
	{
		Assert.assertEquals(0123456,p.getPhone());
	}
	@Test
	public void testPerson6()
	{
		Assert.assertEquals("Executed", p.display());
	}
}
