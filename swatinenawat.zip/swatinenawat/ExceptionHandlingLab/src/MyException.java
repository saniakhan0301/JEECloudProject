
import java.lang.Exception;
class MyException extends Exception
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String toString()
	{
		return "Please Enter Name";
	}
}