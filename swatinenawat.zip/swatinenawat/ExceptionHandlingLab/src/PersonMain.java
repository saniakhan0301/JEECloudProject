import java.util.*;
import java.io.*;
import java.lang.Exception;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;



public class PersonMain {

	
	public static void main(String args[])
	{
		
		String firstName,lastName;
		long phoneNo;
		String gender;
		Scanner sc=new Scanner(System.in);
		try {
			System.out.println("Enter first name: ");
			firstName = sc.nextLine();
			if(firstName.equals(""))
				throw new MyException();
			System.out.println("Enter Last name: ");
			lastName = sc.nextLine();
			if(lastName.equals(""))
				throw new MyException();
			int flag=0;
			gender="F";
			while(flag!=1) {
			System.out.println("Enter Gender: ");
			gender = sc.nextLine();
			Gender[] gArray= Gender.values();
			
			for(Gender g1:gArray)
			{
				String gen=g1.toString();
				if(gen.equals(gender))
					flag=1;
				
				
				
			}
			if(flag==0)
				System.out.println("Invalid Gender");
			}
			System.out.println("Enter Phone Number: ");
			phoneNo = sc.nextLong();
			System.out.println("Enter Dob: ");
			String dob = sc.next();
			PersonMain perMain=new PersonMain();
			int age = perMain.calAge(dob);
			Person person=new Person(firstName,lastName,gender,phoneNo,age);
			String s=person.display();
		}
		catch(MyException e)
		{
			System.out.println("Exception Caught:"+e);
		}
		catch(Exception e) {
			System.out.println(e);
		}
		finally {
		sc.close();}
	}

	public int calAge(String dob)
	{
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyy");
		LocalDate dob1=LocalDate.parse(dob,formatter);
		LocalDate curr=LocalDate.now();
		Period period=dob1.until(curr);
		return period.getYears();
	}
}
