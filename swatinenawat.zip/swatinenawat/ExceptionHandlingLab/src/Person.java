
public class Person {

	

		private String firstName;
		private String lastName;
		private String gender;
		private long phoneNo;
		private int age;
		Person()
		{
			// System.out.println("Object Created");
		}
		Person(String firstName,String lastName,String gender,long phoneNo,int age)
		{
			this.firstName=firstName;
			this.lastName=lastName;
			this.gender=gender;
			this.phoneNo=phoneNo;
			this.age=age;
		}
		public void setFirstName(String firstName)
		{
			this.firstName=firstName;
		}
		public void setLastName(String LastName)
		{
			this.firstName=lastName;
		}
		public void setGender(String gender)
		{
			this.firstName=gender;
		}
		public String getFirstName()
		{
			return this.firstName;
		}
		public String getLastName()
		{
			return this.lastName;
		}
		public String getGender()
		{
			return this.gender;
		}
		public int getAge()
		{
			return this.age;
		}
		public long getPhone()
		{
			return this.phoneNo;
		}
		public String display()
		{
			System.out.println("Person Details:");
			System.out.println("");
			System.out.println("------------------------");
			System.out.println("First Name: "+firstName);
			System.out.println("Last Name: "+lastName);
			Person p=new Person();
			String fullName=p.calFullName(firstName,lastName);
			System.out.println("Full Name: "+fullName);
			System.out.println("Gender: "+gender);
	        System.out.println("Phone Number: "+phoneNo);
	        System.out.println("Age: "+age);
	        return "Executed";
		}
		public String calFullName(String firstName,String lastName)
		{
			return firstName+" "+lastName;
		}
		
	
}
