import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Purchaseproduct {

	public void displayExpiryDate(String purchaseDate,int waranteeYears,int waranteeMonths)
	{
		DateTimeFormatter formatter= DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate purchase=LocalDate.parse(purchaseDate,formatter);
		
		System.out.println("Expiry Date is "+purchase.plusYears(waranteeYears).plusMonths(waranteeMonths));
		
	}
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter purchase date in format dd/MM/YYYY: ");
		String purchaseDate=sc.nextLine();
		System.out.println("Enter warantee period : ");
		System.out.println("Years: ");
		int waranteeYears=sc.nextInt();
		System.out.println("Months: ");
		int waranteeMonths=sc.nextInt();
		Purchaseproduct p=new Purchaseproduct();
		p.displayExpiryDate(purchaseDate, waranteeYears,waranteeMonths);
	}
	
}
