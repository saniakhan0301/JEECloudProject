import java.util.Scanner;
import java.time.*;
public class TimeZone {

	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("1:America/New_York, 2:Europe/London, 3:Asia/Tokyo, 4:US/Pacific, 5:Africa/Cairo, 6:Australia/Sydney ");
		System.out.println("Enter your choice");
		int choice=sc.nextInt();
		TimeZone t=new TimeZone();
		
		switch(choice)
		{
		case 1: t.displayTimeZone("America/New_York");break;
		case 2: t.displayTimeZone("Europe/London");break;
		case 3: t.displayTimeZone("Asia/Tokyo");break;
		case 4: t.displayTimeZone("US/Pacific");break;
		case 5: t.displayTimeZone("Africa/Cairo");break;
		case 6: t.displayTimeZone("Australia/Sydney");break;
		}
		
	}
	public void displayTimeZone(String z)
	{
		ZonedDateTime zone =ZonedDateTime.now(ZoneId.of(z));
		System.out.println(zone);
	}
}





