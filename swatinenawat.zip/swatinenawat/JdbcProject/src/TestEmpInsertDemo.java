import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class TestEmpInsertDemo {

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Emp id: ");
		int empId=sc.nextInt();
		System.out.println("Enter Emp name: ");
		String empName=sc.next();
		System.out.println("Enter Emp salary: ");
		int empSal=sc.nextInt();
		String qry="INSERT INTO emp_157794 VALUES(?,?,?)";
		
        Connection con=null;
        PreparedStatement pst=null;
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G","lab1btrg4","lab1boracle");
		    pst=con.prepareStatement(qry);
		    pst.setInt(1, empId);
		    pst.setString(2, empName);
		    pst.setInt(3, empSal);
		    int noOfRecAffected=pst.executeUpdate();
		    System.out.println(noOfRecAffected+" Data is inserted in the table");
		} 
		catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}

	}

}
