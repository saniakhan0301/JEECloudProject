import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class EmpDelRecord {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Emp id: ");
		int empId=sc.nextInt();
		String qry="DELETE FROM emp_157794 where emp_id=?";
		
        Connection con=null;
        PreparedStatement pst=null;
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G","lab1btrg4","lab1boracle");
		    pst=con.prepareStatement(qry);
		    pst.setInt(1, empId);
		    int noOfRecAffected=pst.executeUpdate();
		    System.out.println(noOfRecAffected+" Data is deleted from the table");
		} 
		catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}



	}

}
