import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class EmpUpdateSal
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Emp id: ");
		int empId=sc.nextInt();
		System.out.println("Enter Emp new salary: ");
		int empSal=sc.nextInt();
		String qry="UPDATE emp_157794 SET emp_sal=? WHERE emp_id=?";
		
        Connection con=null;
        PreparedStatement pst=null;
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G","lab1btrg4","lab1boracle");
		    pst=con.prepareStatement(qry);
		    pst.setInt(1, empSal);
		    pst.setInt(2, empId);
		    int noOfRecAffected=pst.executeUpdate();
		    System.out.println(noOfRecAffected+" Data is updated in the table");
		} 
		catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}



	}

}
