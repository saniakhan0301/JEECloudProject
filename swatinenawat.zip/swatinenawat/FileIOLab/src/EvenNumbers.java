import java.io.*;
import java.util.Scanner;

public class EvenNumbers {
	public static void main(String args[])
	{
		FileReader fr=null;;
		Scanner sc=null;
		try {
		  fr=new FileReader("C://swatinenawat//FileIOLab//numbers.txt");
		  
		 sc=new Scanner(fr);
		  String line=sc.nextLine();
		  String [] numbers=line.split(",");
		  for(String s:numbers)
		  {
			  
			  
				  int j=Integer.parseInt(s);
				  if(j%2==0)
					  System.out.println(j);
			  
		  }
		}
		catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}

}
