import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.*;
import java.io.*;

public class ReverseContent {

	public static void main(String args[])
	{
		File myFile=new File("C://swatinenawat/FileIOProject/src/TestEmpReadDemo.java");
		FileReader fr=null;
		BufferedReader br=null;
		FileWriter fw=null;
		BufferedWriter bw=null;
		try {
		fr=new FileReader(myFile);
		br=new BufferedReader(fr);
		ArrayList<Character> arr=new ArrayList<Character>();
		int line=br.read();
		while(line!=-1)
		{
			arr.add((char)line);
			line=br.read();
		}
		
		
		fw=new FileWriter("myProgram1.txt");
		bw=new BufferedWriter(fw);
		int arrlen=arr.size();
		for(int i=arrlen-1;i>=0;i--)
		{
			bw.write(arr.get(i).toString());
			bw.flush();
			
		}
		System.out.println("File Created.");
		
		} 
		catch (IOException e) {
			
			e.printStackTrace();
		}
		
		
	}
	
}
