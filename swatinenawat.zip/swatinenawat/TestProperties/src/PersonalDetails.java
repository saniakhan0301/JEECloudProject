import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;

public class PersonalDetails {

	public static void main(String[] args) {
		FileOutputStream fos=null;
		Properties myDbInfo=null;
		Scanner sc=new Scanner(System.in);
		try {
			fos=new FileOutputStream("PersonProps.properties");
			myDbInfo=new Properties();
			
			
				System.out.println("Enter Id");
				String id=sc.next();
				System.out.println("Enter Name");
				String name=sc.next();
				System.out.println("Enter Salary");
				String sal=sc.next();
				myDbInfo.setProperty("Id", id);
				myDbInfo.setProperty("Name", name);
				myDbInfo.setProperty("Salary", sal);
			
			
			myDbInfo.store(fos,"This Is Data Base Information");
			System.out.println("Data is written in the file.");
		} 
		catch (IOException e) {
			
			e.printStackTrace();
		}
		

	}
}
