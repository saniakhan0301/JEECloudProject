import java.util.Scanner;
import java.util.regex.Pattern;

public class TestvalidationDemo
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your Name");
		String name=sc.next();
		String namePattern1="[A-Z][a-z]+";
		String namePattern2="[0-9]+";
		System.out.println("You have entered : "+name);
		if(Pattern.matches(namePattern1, name))
		{
			System.out.println("Valid name");
		}
		else
		{
			System.out.println("Invalid name");
		}
	}
}
