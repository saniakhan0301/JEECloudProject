import java.io.FileInputStream;
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

public class DisplayProperties {

public static void main(String[] args) {
		
		FileInputStream fis=null;
		Properties myProps=null;
		try {
			
			fis=new FileInputStream("PersonProps.properties");
		    myProps=new Properties();
		    myProps.load(fis);
		    System.out.println("*******Using Property Object**********");
		    Set<Object> ks=myProps.keySet();
		    Collection<Object> vs=myProps.values();
			   Iterator it=ks.iterator();
			   Iterator it1=vs.iterator();
			   while(it.hasNext())
			   {
				   System.out.print(""+it.next());
				   System.out.print(" : "+it1.next());
				   System.out.println("");
			   }
			   System.out.println("");
			
			System.out.println("*******Using get property method**********");
		    String id=myProps.getProperty("Id");
		    String name=myProps.getProperty("Name");
		    String sal=myProps.getProperty("Salary");
		    System.out.println("Credentials : "+id+" : "+name+" : "+sal);
		    System.out.println("********************************");
		    
		    //If we don't know key name
		    
		   
			   
		   
		   
		} 
		catch (IOException e) {
		
			e.printStackTrace();
		}
		
		
	}
}
