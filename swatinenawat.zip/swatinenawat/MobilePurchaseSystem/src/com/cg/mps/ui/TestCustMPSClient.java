package com.cg.mps.ui;


import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mps.dto.Customer;
import com.cg.mps.dto.Mobile;
import com.cg.mps.exception.CustomerException;
import com.cg.mps.service.CustServiceImpl;

public class TestCustMPSClient
{

	
	static CustServiceImpl custService=null;
	static Scanner sc=null;
	public static void main(String[] args)
	{
		
		
		
		custService=new CustServiceImpl();
		sc=new Scanner(System.in);
		System.out.println("**** Welcome To MPS *****");
		int choice=0;
		while(true)
		{
			System.out.println("What do you want to do ?");
			System.out.println("1 : Display Mobile Details \t2 : Add Purchase Details \t3 : Delete Mobile \t4 : Search Mobile \t5 : Exit");
			System.out.println("Enter your choice : ");
			choice=sc.nextInt();
			switch(choice)
			{
				case 1:displayAllMobiles();break;
				case 2:addPurchaseInfo();break;
				case 3:deleteMobileDetails();break;
				case 4:searchMobileDetail();break;
				default: System.exit(0);
				 
			}
		}
		

	}
	private static void displayAllMobiles() {
		ArrayList<Mobile> mobList;
		try {
			mobList = custService.getAllMobile();
			System.out.println("\tMOBILE_ID \tNAME \tPRICE \tQUANTITY ");
			for(Mobile mm:mobList)
			{
				System.out.println("\t"+mm.getMobileId()+"\t"+mm.getName()+"\t"+mm.getPrice()+"\t"+mm.getQuantity());
			}
		} 
		catch (CustomerException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
		
	}
	private static void addPurchaseInfo() {
		int id,dataInserted,mId;
		String name,mail,ph,pdate;
		
		
		try 
		{
			sc=new Scanner(System.in);
			
			System.out.println("Enter customer name:");
			name=sc.next();
			if(custService.validateCustName(name))
			{
				System.out.println("Enter Mailid:");
				mail=sc.next();
				if(custService.validateMailId(mail)) 
				{
					System.out.println("Enter phoneno:");
					ph=sc.next();
					if(custService.validatePhoneNo(ph))
					{
						System.out.println("Enter mobile id:");
						mId=sc.nextInt();
						if(custService.validateMobileId(mId))
						{
							Random r=new Random();
							id=(int)(100*(r.nextDouble()));
							
							pdate="";
							Customer cc=new Customer(id,name,mail,ph,pdate,mId);
							dataInserted=custService.addPurchaseDetail(cc);
							if(dataInserted==1)
							{
								System.out.println("Inserted");
								
							}
							else
								System.out.println("Sorry data is not inserted.");
			
						}
					}
				}
			}
		}
			
			
		 catch (CustomerException e)
		{
			System.out.println(e);
			//e.printStackTrace();
		}
		
	}
	public static void deleteMobileDetails()
	{
		int mid, dataDeleted;
		try
		{
			sc=new Scanner(System.in);
			System.out.println("Enter mobile Id");
			mid= sc.nextInt();
			if(custService.validateMobileId(mid))
			{
				dataDeleted=custService.deleteMobile(mid);
				if(dataDeleted==1)
				{	System.out.println(dataDeleted+" Deleted.");
				

				}
				else
					throw new CustomerException("Not able to delete data");
			}
			else
			{
				throw new CustomerException("Invalid MobileId");
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	public static void searchMobileDetail()
	{
		
		float lowprice,highprice;
		ArrayList<Mobile> mobList;
		try
		{
			sc=new Scanner(System.in);
			System.out.println("Enter low range");
			lowprice=sc.nextFloat();
			System.out.println("Enter high range");
			highprice=sc.nextFloat();
			mobList = custService.searchMobile(lowprice,highprice);
			System.out.println("\tMOBILE_ID \tNAME \tPRICE \tQUANTITY ");
			for(Mobile mm:mobList)
			{
				System.out.println("\t"+mm.getMobileId()+"\t"+mm.getName()+"\t"+mm.getPrice()+"\t"+mm.getQuantity());
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}