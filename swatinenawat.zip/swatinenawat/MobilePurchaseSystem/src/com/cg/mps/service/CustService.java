package com.cg.mps.service;

import java.util.ArrayList;

import com.cg.mps.dto.Customer;
import com.cg.mps.dto.Mobile;
import com.cg.mps.exception.CustomerException;


public interface CustService 
{
	public ArrayList<Mobile> getAllMobile()throws CustomerException;
	public int addPurchaseDetail(Customer cc)throws CustomerException;
	public int deleteMobile(int mobileid) throws CustomerException;
    public ArrayList<Mobile> searchMobile(float lowprice,float highprice)throws CustomerException;
	public boolean validateCustName(String cname)throws CustomerException;
	public boolean validateMailId(String mailid)throws CustomerException;
	public boolean validatePhoneNo(String phoneno)throws CustomerException;
	public boolean validateMobileId(int mobileid)throws CustomerException;
}
