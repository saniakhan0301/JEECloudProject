package com.cg.mps.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.mps.dao.CustDaoImpl;
import com.cg.mps.dto.Customer;
import com.cg.mps.dto.Mobile;
import com.cg.mps.exception.CustomerException;



public class CustServiceImpl implements CustService
{
	CustDaoImpl custDao=null;
    
	public CustServiceImpl() {
		custDao=new CustDaoImpl();
	}

	@Override
	public ArrayList<Mobile> getAllMobile() throws CustomerException
	{
		
		return custDao.getAllMobile();
	}

	@Override
	public int addPurchaseDetail(Customer cc) throws CustomerException {
		
		
		return custDao.addPurchaseDetail(cc);
	}
	@Override
	public int deleteMobile(int mobileid) throws CustomerException
	{
		return custDao.deleteMobile(mobileid);
	}
	@Override
    public ArrayList<Mobile> searchMobile(float lowprice,float highprice)throws CustomerException
    {
		return custDao.searchMobile(lowprice,highprice);

    }

	@Override
	public boolean validateCustName(String cname)throws CustomerException
	{
		String namePattern="[A-Z][a-z]+";
		if(Pattern.matches(namePattern, cname)&&cname.length()<=20)
			return true;
			
		else
			throw new CustomerException("Inavlid Employee Name Should start with capital and only characters allowed");
		
		
	}
	@Override
	public boolean validateMailId(String mailid)throws CustomerException
	{
		String mailPattern="[a-z]+@[a-z]+.com";
		if(Pattern.matches(mailPattern, mailid))
			return true;
			
		else
			throw new CustomerException("Inavlid MailId");
	}
	@Override
	public boolean validatePhoneNo(String phoneno)throws CustomerException
	{
		String phonePattern="[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]";
		if(Pattern.matches(phonePattern, phoneno))
			return true;
			
		else
			throw new CustomerException("Inavlid MailId");
	}
	@Override
	public boolean validateMobileId(int mobileid)throws CustomerException
	{
		String mobileIdPattern="[0-9][0-9][0-9][0-9]";
		String mobId=Integer.toString(mobileid);
		if(Pattern.matches(mobileIdPattern, mobId))
			return true;
			
		else
			throw new CustomerException("Inavlid Mobile Id");
	}


 
}
