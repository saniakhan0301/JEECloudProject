package com.cg.mps.exception;

public class CustomerException extends Exception
{
	String msg;

	public CustomerException(String msg) {
		super();
		this.msg = msg;
		System.out.println(msg);
	}
	

}
