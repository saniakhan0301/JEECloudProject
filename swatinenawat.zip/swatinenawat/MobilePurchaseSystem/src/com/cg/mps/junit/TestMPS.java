package com.cg.mps.junit;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.cg.mps.dto.Customer;
import com.cg.mps.dto.Mobile;
import com.cg.mps.exception.CustomerException;
import com.cg.mps.service.CustServiceImpl;
import junit.framework.Assert;

public class TestMPS 
{
	static CustServiceImpl cust=null;
	static Customer cc=null;
	static ArrayList<Mobile> a=null;
	
	
	@BeforeClass
	public static void setUp()
	{
		cust=new CustServiceImpl();
		a=new ArrayList<Mobile>();
		a.add(new Mobile(1003,"Sony xperia C",15000.0f,30));
		
		cc=new Customer(121,"Neha","neha@gmail.com","0123654789","",1007);
		
		
		
		System.out.println("setUp is call once "+" Before the execution of "+"all test cases ");
		
		
	}
	@AfterClass
	public static void tearDown()
	{
		System.out.println("tearDown is call once "+" After the execution of "+"each test cases ");

	}
	@Before
	public  void init()
	{
		System.out.println("init is call once "+" Before the execution of "+"each test cases ");

	}
	@After
	public void detroy()
	{
		System.out.println("detroy is call once "+" After the execution of "+"each test cases ");

	}

	@Test
	@Ignore
	public void testInsert()
	{
		
			try {
				
				Assert.assertEquals(1,cust.addPurchaseDetail(cc));
			} catch (CustomerException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
	@Test
	public void testSearch()
	{
		try {
			
			
			
			Assert.assertEquals(a,cust.searchMobile(14000, 15000));
			
		} catch (CustomerException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
	}
}
