package com.cg.mps.dao;

import java.util.ArrayList;


import com.cg.mps.dto.Customer;
import com.cg.mps.dto.Mobile;
import com.cg.mps.exception.CustomerException;

public interface CustDao 
{
	public ArrayList<Mobile> getAllMobile()throws CustomerException;
	public int addPurchaseDetail(Customer cc)throws CustomerException;
    public int deleteMobile(int mobileid) throws CustomerException;
    public ArrayList<Mobile> searchMobile(float lowprice,float highprice)throws CustomerException;

}
