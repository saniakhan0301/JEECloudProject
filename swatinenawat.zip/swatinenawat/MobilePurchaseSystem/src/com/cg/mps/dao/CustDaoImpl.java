package com.cg.mps.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mps.dto.Customer;
import com.cg.mps.dto.Mobile;
import com.cg.mps.exception.CustomerException;
import com.cg.mps.ui.TestCustMPSClient;
import com.cg.mps.util.DBUtil;



public class CustDaoImpl implements CustDao
{
	static Logger myLogger=Logger.getLogger(CustDaoImpl.class);
	

	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;

	@Override
	public ArrayList<Mobile> getAllMobile() throws CustomerException 
	{
		ArrayList<Mobile> mobList=null;
		try {
			mobList=new ArrayList<Mobile>();
			con=DBUtil.getConn();
			
			String selectqry="SELECT * FROM mobile";
			st=con.createStatement();
			rs=st.executeQuery(selectqry);
			while(rs.next())
			{
				
				mobList.add(new Mobile(rs.getInt("mobileid"),rs.getString("name"),rs.getFloat("price"),rs.getInt("quantity")));
			}
			
			
		} 
		catch (Exception e) 
		{
			throw new CustomerException(e.getMessage());
		} 
		finally
		{
			try 
			{
				st.close();
				rs.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				
				throw new CustomerException(e.getMessage());

			}
		}
		
		return mobList;
		
	}

	@Override
	public int addPurchaseDetail(Customer cc) throws CustomerException
	{
		int data;
		PropertyConfigurator.configure("log4j.properties");
		try 
		{
			
			con=DBUtil.getConn();
			String checkquery="SELECT * FROM mobile WHERE mobileid=?";
			pst=con.prepareStatement(checkquery);
			pst.setInt(1, cc.getMobileid());
			rs=pst.executeQuery();
			int quant=0;
			while(rs.next())
				quant=rs.getInt("quantity");
			if(quant>0) 
			{
				String insertqry="INSERT INTO purchasedetail VALUES(?,?,?,?,?,?)";
				pst=con.prepareStatement(insertqry);
				pst.setInt(1, cc.getPurchaseid());
				pst.setString(2, cc.getCname());
				pst.setString(3, cc.getMailid());
				pst.setString(4, cc.getPhoneno());
				
				Calendar currenttime= Calendar.getInstance();
				Date sqldate=new Date((currenttime.getTime()).getTime());
				pst.setDate(5, (java.sql.Date)sqldate);
				pst.setInt(6, cc.getMobileid());
				data=pst.executeUpdate();
				//update mobile table
				String qry="UPDATE mobile SET quantity=? WHERE mobileid=?";
				pst=con.prepareStatement(qry);
				quant-=1;
			    pst.setInt(1, quant);
			    pst.setInt(2, cc.getMobileid());
			    int noOfRecAffected=pst.executeUpdate();
			    System.out.println(noOfRecAffected+" Purchase detail inserted.");
			    myLogger.info("Purchase Details Inserted : ");
			    myLogger.info("Customer Details : "+cc);
			   // while(rs.next()) {
			   // myLogger.info("Mobile Details : Id = "+rs.getInt("mobileid")+" Name = "+rs.getString("name")+" Price = "+rs.getFloat("price")+" Quantity = "+rs.getInt("quantity"));
			   // }
			}
			else 
				throw new CustomerException("Requested Mobile is not in stock");
		} 
		catch (Exception e) 
		{
			 myLogger.error("Purchase Detail Not Inserted: "+e);
			throw new CustomerException(e.getMessage());
		}
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				
				throw new CustomerException(e.getMessage());

			}
		}
		
		return data;
		
		
		
	}
	@Override
	public int deleteMobile(int id) throws CustomerException
    {
		// ArrayList<Mobile> mobList=null;
	    int data=0;
		PropertyConfigurator.configure("log4j.properties");

		try
		{
			//myLogger.debug("This is debug Message");
			//myLogger.warn("This is warn Message");
			//myLogger.fatal("This is fatal Message");
			//mobList=new ArrayList<Mobile>();
			con=DBUtil.getConn();
			
			String qry1="DELETE FROM mobile WHERE mobileid = ?";
			pst=con.prepareStatement(qry1);
			pst.setInt(1, id);
		    data=pst.executeUpdate();
		   
		    myLogger.info("Mobile data Deleted.");

		    
		}
		catch(Exception e)
		{
		    myLogger.error("Mobile Not Deleted : ");
			throw new CustomerException(e.getMessage());

			//e.printStackTrace();
		}
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				
				throw new CustomerException(e.getMessage());

			}
		}
		
		return data;
		
    }
	@Override
    public ArrayList<Mobile> searchMobile(float lowprice,float highprice)throws CustomerException
    {
		ArrayList<Mobile> mobList=null;
		PropertyConfigurator.configure("log4j.properties");

		try
		{
			mobList=new ArrayList<Mobile>();
			con=DBUtil.getConn();
			String checkquery="SELECT * FROM mobile WHERE price<=? and price>=?";
			pst=con.prepareStatement(checkquery);
			pst.setFloat(1, highprice);
			pst.setFloat(2, lowprice);
			rs=pst.executeQuery();
			
			while(rs.next())
			{	
				mobList.add(new Mobile(rs.getInt("mobileid"),rs.getString("name"),rs.getFloat("price"),rs.getInt("quantity")));
			}
			
		    myLogger.info("User searched for Mobile in range "+lowprice+" to "+highprice);

		}
		catch(Exception e)
		{
		    myLogger.error("No mobiles in this range");

			throw new CustomerException("No mobiles in this range");
		}
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				
				throw new CustomerException(e.getMessage());

			}
		}
		
		return mobList;
    }



}
