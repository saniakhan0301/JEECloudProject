import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
public class TestHashMapDemo {
	public static void main(String args[])
	{
		HashMap<Long,String> directory= new HashMap<Long,String>();
		directory.put(8888881002210L, "swati");
		directory.put(8888881002516L, "Anagha");
		directory.put(8888881002218L, "prajakta");
		directory.put(8888881002290L, "sarvada");
		directory.put(8888881002210L, "Neha");
		
		System.out.println(directory);
		System.out.println("******Print enteries******");
		Set<Map.Entry<Long,String>> mapset=directory.entrySet();
		Iterator<Map.Entry<Long,String>> it=mapset.iterator();
		
		while(it.hasNext())
		{
			Map.Entry<Long, String> entry =it.next();
		    System.out.println("Key : "+entry.getKey()+" Name : "+entry.getValue());
		}
		
		System.out.println("******Print Keys******");
		Set<Long> kset=directory.keySet();
		Iterator<Long> it1=kset.iterator();
		
		while(it1.hasNext())
		{
			System.out.println("Key : "+it1.next());
		   
		}
		
		System.out.println("******Print Values******");
		Collection<String> vset= directory.values();
		Iterator<String> it2=vset.iterator();
		while(it2.hasNext())
		{
			System.out.println("Values : "+it2.next());
		   
		}
	}

}
