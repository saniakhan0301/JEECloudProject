package com.cg.hms.service;

import java.time.LocalDate;
import java.time.Period;
import java.util.regex.Pattern;

public class HotelBookingValidationServiceImpl implements
		HotelBookingValidationService 
{
	@Override
	public boolean validateName(String name)
	{
		String namePattern="[A-Z][a-z]+";
		if(Pattern.matches(namePattern, name)&&name.length()<=30)
			return true;
			
		return false;
	}

	@Override
	public boolean validateEmail(String email)
	{
		
		String mailPattern="[a-z]{1,10}+[0-9]{0,5}+@[a-z]{1,10}+.com";
		if(Pattern.matches(mailPattern, email))
			return true;
			
		return false;
	}

	@Override
	public boolean validateContact(String contact)
	{
		
		String phonePattern="[0-9]{10}";
		if(Pattern.matches(phonePattern, contact))
			return true;
			
		return false;
	}

	@Override
	public boolean validatePassword(String password)
	{
		String pattern = "(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,15}";
		if(password.matches(pattern))
			return true;
		
		return false;
	}
	@Override
	public boolean validateDate(LocalDate date) 
	{
		LocalDate d=LocalDate.now();
		Period p = Period.between(d, date);
		if(p.getDays()>=0)
			return true;
		return false;
	}

	@Override
	public boolean validateCheckOutDate(LocalDate checkInDate,LocalDate checkOutDate)
	{
		Period p = Period.between(checkInDate,checkOutDate);
		if(p.getDays()>0)
			return true;
		return false;
	}

	@Override
	public boolean validateUserId(String userId) 
	{
		String Pattern5="[0-9]{3}";
		if(Pattern.matches(Pattern5, userId))
			return true;
			
		
		
		return false;
	}

	@Override
	public boolean validateRating(String rating) 
	{
		String Pattern4="[1-5]";
		if(Pattern.matches(Pattern4, rating))
			return true;
			
		
		
		return false;
		
	}

	@Override
	public boolean validateHotelId(String hotelId)
	{
		String Pattern3="[0-9]{3}";
		if(Pattern.matches(Pattern3, hotelId))
			return true;
			
		
		
		return false;
		
	}

	@Override
	public boolean validateCost(String cost) 
	{
		String Pattern2="[0-9]{1,7}";
		if(Pattern.matches(Pattern2, cost))
			return true;
			
		
		
		return false;
		
	}

	public boolean validateDateFormat(String dateCheck) 
	{
		String Pattern1="[0-3]+[0-9]+/+[0-1]+[0-9]+/+[2]+[0]+[1]+[8]";
		if(Pattern.matches(Pattern1, dateCheck))
			return true;
			
		
		
		return false;
	}

}
