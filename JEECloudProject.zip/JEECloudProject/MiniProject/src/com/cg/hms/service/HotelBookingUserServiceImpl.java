package com.cg.hms.service;

import java.util.ArrayList;

import com.cg.hms.dao.HotelBookingUserDaoImpl;
import com.cg.hms.dto.BookingDetails;
import com.cg.hms.dto.Hotel;
import com.cg.hms.dto.RoomDetails;
import com.cg.hms.dto.User;
import com.cg.hms.exception.HotelBookingException;

public class HotelBookingUserServiceImpl implements HotelBookingUserService {

	HotelBookingUserDaoImpl hbdao=null;
	public HotelBookingUserServiceImpl() 
	{
		 hbdao=new HotelBookingUserDaoImpl(); 
	}

	@Override
	public int register(User user) throws HotelBookingException 
	{
		return hbdao.register(user);
	}

	@Override
	public String login(int role,int userId, String password) throws HotelBookingException 
	{
			return hbdao.login(role,userId, password);
	}


	public String bookRoom(String uid,String dateCheckIn, String dateCheckOut, int adult, int children, float cost,String hotelId,String roomId)throws HotelBookingException 
	{
		return hbdao.bookRoom(uid,dateCheckIn,dateCheckOut,adult,children,cost,hotelId,roomId);
		
	}

	@Override
	public ArrayList<BookingDetails> viewBookingStatus(int bookingId)
			throws HotelBookingException 
	{
		
		return hbdao.viewBookingStatus(bookingId);
	}

	@Override
	public ArrayList<RoomDetails> searchRoom(int hotelId)
			throws HotelBookingException
	{
		
		return hbdao.searchRoom(hotelId);
	}


	public Boolean checkAvailability(String hotelId, String typeOfRoom)throws HotelBookingException
	{
		return hbdao.checkAvailability(hotelId, typeOfRoom);
		
	}

	@Override
	public float calculateCost(int day,String rid)throws HotelBookingException
	{
		
		return hbdao.calculateCost(day,rid);
	}


	public ArrayList<RoomDetails> displayRooms(String hotelId)throws HotelBookingException
	{
		return hbdao.displayRooms(hotelId);
		
	}

	@Override
	public ArrayList<Hotel> displayHotelByCity(String city)
			throws HotelBookingException {
		
		return hbdao.displayHotelByCity(city);
	}


}
