package com.cg.hms.service;

import java.time.LocalDate;

public interface HotelBookingValidationService 
{

	public boolean validateName(String name);
	public boolean validateEmail(String email);
	public boolean validateContact(String contact);
	public boolean validatePassword(String password);
	public boolean validateDate(LocalDate date);
	public boolean validateCheckOutDate(LocalDate checkInDate,LocalDate checkOutDate);
	public boolean validateUserId(String userId);
	public boolean validateRating(String rating);
	public boolean validateHotelId(String hotelId);
	public boolean validateCost(String cost);
}