package com.cg.hms.service;

import java.util.ArrayList;
import java.util.Date;



import com.cg.hms.dao.HotelBookingAdminDaoImpl;
import com.cg.hms.dto.BookingDetails;
import com.cg.hms.dto.Hotel;
import com.cg.hms.dto.RoomDetails;
import com.cg.hms.exception.HotelBookingException;

public class HotelBookingAdminServiceImpl implements HotelBookingAdminService 
{
	HotelBookingAdminDaoImpl hbdao=null;
	public HotelBookingAdminServiceImpl() 
	{
		 hbdao=new HotelBookingAdminDaoImpl(); 
	}

	
	@Override
	public String login(int role,int userId, String password) throws HotelBookingException 
	{
			return hbdao.login(role,userId, password);
	}

	@Override
	public int addHotel(Hotel hotel) throws HotelBookingException 
	{
		return hbdao.addHotel(hotel);
	}

	@Override
	public int modifyHotel(int hotelId,String description)throws HotelBookingException 
	{
		
		return hbdao.modifyHotel(hotelId,description);
	}

	@Override
	public int deleteHotel(int hotelId) throws HotelBookingException 
	{
		
		return hbdao.deleteHotel(hotelId);
	}

	@Override
	public int addRoom(RoomDetails room) throws HotelBookingException 
	{
		
		return hbdao.addRoom(room);
	}


	@Override
	public int deleteRoom(String hotelId,String roomId) throws HotelBookingException 
	{
		
		return hbdao.deleteRoom(hotelId,roomId);
	}

	

	@Override
	public ArrayList<Hotel> displayHotels() throws HotelBookingException 
	{
		
		return hbdao.displayHotels();
	}

	@Override
	public ArrayList<BookingDetails> viewBookingByHotel(int hotelId)
			throws HotelBookingException 
	{
		
		return hbdao.viewBookingByHotel(hotelId);
	}

	@Override
	public ArrayList<BookingDetails> viewGuestListOfHotel(int hotelId)
			throws HotelBookingException
	{
		
		return hbdao.viewGuestListOfHotel(hotelId);
	}

	@Override
	public ArrayList<BookingDetails> viewBookingByDate(Date date)
			throws HotelBookingException 
	{
		
		return hbdao.viewBookingByDate(date);
	}

	
	@Override
	public ArrayList<Hotel> displayHotelByCity(String city)
			throws HotelBookingException {
		
		return hbdao.displayHotelByCity(city);
	}

	
	
}
