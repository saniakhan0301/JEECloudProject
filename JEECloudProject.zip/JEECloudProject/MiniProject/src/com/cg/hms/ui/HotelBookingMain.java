package com.cg.hms.ui;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

import com.cg.hms.dto.BookingDetails;
import com.cg.hms.dto.Hotel;
import com.cg.hms.dto.RoomDetails;
import com.cg.hms.dto.User;
import com.cg.hms.exception.HotelBookingException;
import com.cg.hms.service.HotelBookingAdminServiceImpl;
import com.cg.hms.service.HotelBookingUserServiceImpl;
import com.cg.hms.service.HotelBookingValidationServiceImpl;


public class HotelBookingMain 
{
	
	static Scanner sc=new Scanner(System.in);
	static HotelBookingAdminServiceImpl hbas=null;
	static HotelBookingUserServiceImpl hbus=null;
	static HotelBookingValidationServiceImpl hbvs=null;
	static int userMainId=0;
	
	public static void main(String args[])
	{
		
		choice();	
	}
	
	public static void choice()
	{
		String role;
		System.out.println("Press\n1 for Admin\n2 for User\n3 for Exit");
		System.out.println("Enter your choice: ");
		
		role=sc.next();
		
		
		if(role.equals("1"))
		{
			adminDisplay();
		}
		else if(role.equals("2"))
		{
			userDisplay();
		}
		else if(role.equals("3"))
		{
			System.out.println("Thank You for using Hotel Booking Application");
			
			
			 int n = 10;
		        for (int i = -3*n/2; i <= n; i++) {
		            for (int j = -3*n/2; j <= 3*n/2; j++) {

		                // inside either diamond or two circles
		                if ((Math.abs(i) + Math.abs(j) < n)
		                    || ((-n/2-i) * (-n/2-i) + ( n/2-j) * ( n/2-j) <= n*n/2)
		                    || ((-n/2-i) * (-n/2-i) + (-n/2-j) * (-n/2-j) <= n*n/2)) {
		                    System.out.print("* ");
		                }
		                else {
		                    System.out.print("  ");
		                }
		            }
		            System.out.println();
		        }
		
			System.exit(1);
		}
		else
		{
			System.out.println("Wrong Input!");
			choice();
		}
	}
	    //***************     ADMIN        **************************
	
	public static void adminDisplay()
	{
		
		System.out.println("**********Admin Login**************");
		hbas=new HotelBookingAdminServiceImpl();
		hbvs=new HotelBookingValidationServiceImpl();
		int choice,adminId=0;
		String password,aId;
		System.out.print("Enter login Id : ");
		aId=sc.next();
		if(hbvs.validateUserId(aId))
		{
			adminId=Integer.parseInt(aId);
		}
		else
		{
			System.out.println("Invalid Input! Number required between 100-999");
			adminDisplay();
		}
		System.out.println("");
		System.out.print("Enter login password : ");
		password=sc.next();
		System.out.println("");
		try 
		{
			 String logName=hbas.login(1,adminId, password);
			 System.out.println("Welcome "+logName);
			 userMainId=adminId;
			 System.out.println();System.out.println();
			 adminOptions();
		} 
		catch (HotelBookingException e) 
		{
			System.out.println(e.getMessage());
			adminDisplay();
		}	
	}
	public static void adminOptions()
	{
		 System.out.println("1:Add Hotel");
		 System.out.println("2:Delete Hotel");
		 System.out.println("3:Modify Hotel");
		 System.out.println("4:Add Room");
		 System.out.println("5:Delete Room");
		 System.out.println("6:Modify Room");
		 System.out.println("7:Generate Report");
		 System.out.println("8:Logout");
		 System.out.println("Enter your choice");
		 String choice=sc.next();
		 
		 switch(choice)
		 {
		 	case "1":addHotel();break;
		 	case "2":deleteHotel();break;
		 	case "3":modifyHotel();break;
		 	case "4":addRoom();break;
		 	case "5":deleteRoom();break;
		 	case "6":modifyRoom();break;
		 	case "7":generateReport();break;
		 	case "8":choice();break;
		 	default:System.out.println("Invalid Input!");adminOptions();
		 }
	}

	      
	private static void modifyRoom() 
	{
		hbvs=new HotelBookingValidationServiceImpl();
		hbas=new HotelBookingAdminServiceImpl();
		System.out.println("*****************Modify Room****************");
		System.out.println("Enter the Hotel Id : ");
		String hotelId=sc.next();
		if(!hbvs.validateHotelId(hotelId))
		{
			System.out.println("Invalid Hotel Id! Try Again");
			modifyRoom();
		}
		
		System.out.println("Enter the Room Id : ");
		String rid=sc.next();
		if(!(rid.equals("111")||rid.equals("222")||rid.equals("333")))
		{
			System.out.println("Invalid Room Id!");
			modifyRoom();
		}
		try 
		{
			hbas.deleteRoom(hotelId,rid);
			
			System.out.print("\n Enter the Room Type : ");
			String  roomType=sc.next();
			if(!(roomType.equals("small")||roomType.equals("medium")||roomType.equals("large")))
			{
				System.out.println("Invalid Room Type!!");
				modifyRoom();
			}
			String cost="";
			while(true)
			{
				System.out.print("\n Enter the room cost:");
				cost =sc.next();
				if(!hbvs.validateCost(cost))
				{
					System.out.println("Invalid cost");
				}
				else
					break;
			}
			float  roomCost=Float.parseFloat(cost);
			String roomAvailable="";
			while(true)
			{
				System.out.print("\n Enter the room availability:");
				roomAvailable=sc.next();
				if(!hbvs.validateCost(roomAvailable))
				{
					System.out.println("Invalid input");
				}
				else
					break;
			}
			System.out.println("Enter room photo url");
			String photo=sc.next();
			
			RoomDetails rd=new RoomDetails(hotelId,rid,roomType,roomCost,roomAvailable,photo);
			int data=hbas.addRoom(rd);
			adminOptions();
		} 
		catch (HotelBookingException e) 
		{
			
			System.out.println(e.getMessage());
			modifyRoom();
		}
	}

	private static void deleteRoom() 
	{
		hbvs=new HotelBookingValidationServiceImpl();
		hbas=new HotelBookingAdminServiceImpl();
		System.out.println("****************Delete Room*********************");
		System.out.println("Enter the Hotel Id : ");
		String hotelId=sc.next();
		if(!hbvs.validateHotelId(hotelId))
		{
			System.out.println("Invalid Hotel Id! Try Again");
			deleteRoom();
		}
		System.out.println("Enter the Room Id : ");
		String rid=sc.next();
		if(!(rid.equals("111")||rid.equals("222")||rid.equals("333")))
		{
			System.out.println("Invalid Room Id!");
			deleteRoom();
		}
		try 
		{
			int data=hbas.deleteRoom(hotelId,rid);
			System.out.println("Room Deleted Successfully");
			adminOptions();
		} 
		catch (HotelBookingException e) 
		{
			System.out.println(e.getMessage());
			deleteRoom();
		}
		
	}

	public static void modifyHotel() 
	{
		hbvs=new HotelBookingValidationServiceImpl();
		hbas=new HotelBookingAdminServiceImpl();
		System.out.println("***************Modify Hotel**********************");
		int d=0;
		int hid=0;
		System.out.println("Enter ID to modify Hotel Details : ");
		String hotelId=sc.next();
		if(!hbvs.validateHotelId(hotelId))
		{
			System.out.println("Invalid Hotel Id! Try Again");
			modifyHotel();
		}
		hid=Integer.parseInt(hotelId);
		System.out.println("Enter new Description : ");
		String newDescription=sc.next();
		try 
		{
			d=hbas.modifyHotel(hid,newDescription);
			if(d!=0)
			{
				System.out.println("Hotel with Id "+hid+" updated \n\n");
				adminOptions();
			}
			else
			{
				System.out.println("Hotel Id does not exists!");
				modifyHotel();
			}
			
		} 
		catch (HotelBookingException e) 
		{
			System.out.println(e.getMessage());
			modifyHotel();
		}
		
	}
	
	public static void registerUser()
	{
		
		hbus=new HotelBookingUserServiceImpl();
		hbvs=new HotelBookingValidationServiceImpl();
		int userId;
		String	uPassword;
		String	uRole;
		String	uName;
		String	uMobno;
		String	uPhone;
		String	uAddress;
		String	uEmail;
		System.out.println("Enter User Details : ");
		while(true)
		{
			System.out.println("Enter User Name : ");
			uName=sc.next();
			if(hbvs.validateName(uName))
			{
				break;
			}
			else
				System.out.println("Invalid Name! Name should start with capital letter and should contain only letters.");
		}
		while(true)
		{
			System.out.println("Enter Password : ");
			uPassword=sc.next();
			if(hbvs.validatePassword(uPassword))
			{
				break;
			}
			else
				System.out.println("Invalid Password!");
		}
		while(true)
		{
			System.out.println("Enter User Mobile No : ");
			uMobno=sc.next();
			if(hbvs.validateContact(uMobno))
			{
				break;
			}
			else
				System.out.println("Invalid Mobile Number!");
		}
		while(true)
		{
			System.out.println("Enter User Phone no : ");
			uPhone=sc.next();
			if(hbvs.validateContact(uPhone))
			{
				break;
			}
			else
				System.out.println("Invalid Mobile Number!");
		}
		System.out.println("Enter User Address : ");
		uAddress=sc.next();
		while(true)
		{
			System.out.println("Enter User Email : ");
			uEmail=sc.next();
			if(hbvs.validateEmail(uEmail))
			{
				break;
			}
			else
				System.out.println("Invalid Email Id!");
		}
		User u=new User(0,uPassword,"customer",uName,uMobno,uPhone,uAddress,uEmail);
		try 
		{
			userId=hbus.register(u);
			if(userId!=0)
			{
				System.out.println("Your uid is "+userId);
				loginUser();
			}
		} 
		catch (HotelBookingException e) 
		{
			System.out.println(e);
			registerUser();
		}
		
	}
	
	public static void loginUser()
	{
		hbvs=new HotelBookingValidationServiceImpl();
		hbus=new HotelBookingUserServiceImpl();
		
		System.out.println("*************User Login****************");
		int uId=0;
		String log="";
		String	uPassword;
		System.out.println("Enter User Id");
		String user=sc.next();
		if(hbvs.validateUserId(user))
		{
			uId=Integer.parseInt(user);
		}
		else
		{
			System.out.println("Invalid User Id");
			System.out.println("Try Again");
			loginUser();
		}
		System.out.println("Enter Password");
		uPassword=sc.next();
		try 
		{
			log=hbus.login(0,uId,uPassword);
			System.out.println("Welcome "+log);
			userMainId=uId;
			while(true)
			{	 System.out.println("1:Search Hotel");
				 System.out.println("2:Book Hotel");
				 System.out.println("3:View Booking Details");
				 System.out.println("4:Loggout");
				 System.out.println("Enter your choice");
				 String choice=sc.next();
				 
				 switch(choice)
				 {
				 	case "1":searchHotel();break;
				 	case "2":bookHotel();break;
				 	case "3":viewBookingDetails();break;
				 	case "4":choice();break;
				 	default:System.out.println("Invalid input");
				 }
			 
			}
		    
		
		} 
		catch (HotelBookingException e) 
		{
			System.out.println(e.getMessage());
			loginUser();
		}
		
	}
	
	
	

	public static void userDisplay()
	{
		
		userOptions();
			
	}
	public static void userOptions()
	{
		System.out.println("1:Register");
		System.out.println("2:login");
		System.out.println("3:Exit");
	    System.out.println("Enter your choice");
		String choice=sc.next();
			 
		switch(choice)
		{
			case "1":registerUser();break;
			case "2":loginUser();break;
			case "3":choice();break;
			default:System.out.println("Invalid input");userOptions();
		}
	}
	
	public static void searchHotel()
	{
		hbvs=new HotelBookingValidationServiceImpl();
		hbus=new HotelBookingUserServiceImpl();
		System.out.println("Enter City Name : ");
		String city=sc.next();
		city=city.toUpperCase();
		ArrayList<Hotel> hList;
		try 
		{
			
			hList = hbus.displayHotelByCity(city);
			System.out.println("HOTEL_ID \t NAME \t\tCITY \t\t Address \t\t Cost \t\tDescription");
			for(Hotel hh:hList)
			{
				System.out.println(hh.getHotel_id()+"\t\t"+hh.getHotel_name()+"\t\t"+hh.getCity()+"\t\t"+hh.getAddress()+"\t\t"+hh.getCost()+"\t\t"+hh.getDescription());
			}
		} 
		catch (HotelBookingException e)
		{
			
			System.out.println(e.getMessage());
			searchHotel();
		}
		
	}
	
	public static void generateReport()
	{
		System.out.println("****************Reports******************");
		System.out.println("1:List of Hotels\n2:View booking of specific hotel\n3:View guest list of specific hotel\n4:View booking for specific date\n5:Exit");
		System.out.println("Enter your choice");
		String choice=sc.next();
		switch(choice)
		{
			case "1":displayHotels();break;
			case "2":viewBookingByHotel();break;
			case "3":viewGuestListOfHotel();break;
			case "4":viewBookingByDate();break;
			case "5":adminOptions();;break;
			default:System.out.println("Invalid Input");generateReport();
				
		}
	
	}
	
	public static void displayHotels()
	{
		hbvs=new HotelBookingValidationServiceImpl();
		hbas=new HotelBookingAdminServiceImpl();
		System.out.println("***************Hotel Details********************");
		ArrayList<Hotel> hList;
		try 
		{
			
			hList = hbas.displayHotels();
			System.out.println("HOTEL_ID \t NAME \t\tCITY \t\t Address \t Cost \tDescription");
			for(Hotel hh:hList)
			{
				System.out.println(hh.getHotel_id()+"\t\t"+hh.getHotel_name()+"\t\t"+hh.getCity()+"\t\t"+hh.getAddress()+"\t\t"+hh.getCost()+"\t"+hh.getDescription());
			}
			generateReport();
		} 
		catch (HotelBookingException e)
		{
			
			System.out.println(e.getMessage());
			displayHotels();
		}
	}
	public static void addHotel()
	{
		hbvs=new HotelBookingValidationServiceImpl();
		hbas=new HotelBookingAdminServiceImpl();
		System.out.println("****************Add Hotel****************");
		
		int hotelId;
		String	hCity;
		String	hName;
		String	hAddress;
		String	hDescription;
		String	hAvgRate;
		String	hPhno1;
		String	hPhno2;
		String hRating;
		String hEmail;
		String hFax;
		
		System.out.println("*************Enter hotel details**********\n*************************");
		System.out.println("Enter Hotel Name");
		sc.nextLine();
		hName=sc.nextLine();
		
		System.out.println("Enter Hotel City");
		hCity=sc.nextLine();
		hCity=hCity.toUpperCase();
		
		System.out.println("Enter Hotel Address");
		hAddress=sc.nextLine();
		
		System.out.println("Enter Hotel Description");
		hDescription=sc.nextLine();
		
		hAvgRate="0";
		System.out.println("Enter Hotel Phone no1");
		hPhno1=sc.next();
		
		System.out.println("Enter Hotel Phone no2");
		hPhno2=sc.next();
			
		System.out.println("Enter Hotel Rating");
		hRating=sc.next();
		
		System.out.println("Enter Hotel Email-Id");
		hEmail=sc.next();
		
		System.out.println("Enter Hotel Fax");
		hFax=sc.next();
		
		String msg="";
		if(!hbvs.validateContact(hPhno1))
		{
			msg=msg+"Invalid Phone No 1\n";
		}
		if(!hbvs.validateContact(hPhno2))
		{
			msg=msg+"Invalid Phone No 2\n";
		}
		if(!hbvs.validateEmail(hEmail))
		{
			msg=msg+"Invalid email id\n";
		}
		if(!hbvs.validateRating(hRating))
		{
			msg=msg+"Invalid Rating\n";
		}
		if(!msg.equals(""))
		{
			System.out.println(msg+"Please try Again\n");
			addHotel();
		}
		
			Hotel h=new Hotel(null,hCity,hName,hAddress,hDescription,hAvgRate,hPhno1,hPhno2,hRating,hEmail,hFax);
		try 
		{
			hotelId=hbas.addHotel(h);
			
			if(hotelId!=0)
			{
				System.out.println("Your Hotel ID is "+hotelId+"\n\n");
			}
			adminOptions();
		} 
		catch (HotelBookingException e) 
		{
			 
			System.out.println(e.getMessage());
			addHotel();
			
		}
		
	}
	public static void deleteHotel()
	{
		hbvs=new HotelBookingValidationServiceImpl();
		hbas=new HotelBookingAdminServiceImpl();
		System.out.println("******************Delete Hotel****************");
	
		int hid=0,data;
		try 
		{
			System.out.println("Enter Hotel id to delete");
			String hotelId=sc.next();
			if(!hbvs.validateHotelId(hotelId))
			{
				System.out.println("Invalid input");
				deleteHotel();
			}
			hid=Integer.parseInt(hotelId);
			data=hbas.deleteHotel(hid);
			if(data!=0)
				System.out.println(" Deleted Hotel ID "+hid+"\n\n");
			else
				System.out.println("No such ID Exists\n");
			adminOptions();
		}
		catch (HotelBookingException e) 
		{
			System.out.println(e.getMessage());
			deleteHotel();
		}
			
	}
	
	public static void addRoom()
	{
		hbvs=new HotelBookingValidationServiceImpl();
		hbas=new HotelBookingAdminServiceImpl();
		System.out.println("******************Add Room*****************");
		System.out.print("\n Enter the hotel id:");
		String hid=sc.next();
		if(!hbvs.validateHotelId(hid))
		{
			System.out.println("Invalid input");
			addRoom();
		}
		System.out.print("\n Enter the room id:");
		String rid=sc.next();
		if(!(rid.equals("111")||rid.equals("222")||rid.equals("333")))
		{
			System.out.println("Invalid Room Id");
			addRoom();
		}
		String roomType="";
		while(true)
		{
			System.out.print("\n Enter the room type (small/medium/large): ");
			roomType=sc.next();
			if(roomType.equals("small")||roomType.equals("medium")||roomType.equals("large"))
				break;
		}
		String cost="";
		while(true)
		{
			System.out.print("\n Enter the room cost:");
			cost =sc.next();
			if(!hbvs.validateCost(cost))
			{
				System.out.println("Invalid cost");
			}
			else
				break;
		}
		float  roomCost=Float.parseFloat(cost);
		String roomAvailable="";
		while(true)
		{
			System.out.print("\n Enter the room availability:");
			roomAvailable=sc.next();
			if(!hbvs.validateCost(roomAvailable))
			{
				System.out.println("Invalid input");
			}
			else
				break;
		}
		System.out.println("Enter room photo url");
		String photo=sc.next();
		
		RoomDetails rd=new RoomDetails(hid,rid,roomType,roomCost,roomAvailable,photo);
		try 
		{
			int data=hbas.addRoom(rd);
			System.out.println("Room Added");
			adminOptions();
		} 
		catch (HotelBookingException e) 
		{
			
			System.out.println(e.getMessage());
			addRoom();
		}
	}
	
	
	public static void bookHotel() 
	{
		hbvs=new HotelBookingValidationServiceImpl();
		hbus=new HotelBookingUserServiceImpl();
		hbas=new HotelBookingAdminServiceImpl();
		System.out.println("******************Book Room*****************");
		String dateCheckIn="",dateCheckOut="";
		String uid=Integer.toString(userMainId);
		int adult=0,children=0;
		float cost=0;
		ArrayList<RoomDetails> arrl=new ArrayList<RoomDetails>();
		
		try
		{
			
			hbas.displayHotels();
			System.out.println("\nEnter hotel id\n");
			String hotelId=sc.next();
			if(!hbvs.validateHotelId(hotelId))
			{
				System.out.println("Invalid input");
				bookHotel();
			}
			arrl=hbus.displayRooms(hotelId);
			System.out.println("Hotel Id  Room Id  Room Type  Availability");
			for(RoomDetails ee:arrl)
			{
				System.out.println("\t"+ee.getHotel_id()+"\t"
										+ee.getRoom_id()+"\t"
										+ee.getRoom_type()+"\t"
										+ee.getAvailability()+"\t");
			}
			String typeOfRoom="";
			while(true)
			{
				System.out.println(" enter type of room");
				typeOfRoom=sc.next();
				if(!(typeOfRoom.equals("small")||typeOfRoom.equals("medium")||typeOfRoom.equals("large")))
				{
					System.out.println("Invalid Room Type!!");
				}
				else
					break;
			}
			
			String roomid="";
			if(typeOfRoom.equals("small"))
				roomid="111";
			else if(typeOfRoom.equals("medium"))
				roomid="222";
			else if(typeOfRoom.equals("large"))
				roomid="333";
			String rid="";
			while(true)
			{
				System.out.println("Enter room id");
				rid=sc.next();
				if(!(rid.equals(roomid)))
				{
					System.out.println("Invalid room id");
				}
				else
					break;
			}
			boolean availability=hbus.checkAvailability(hotelId,typeOfRoom);
			if(availability==true)
			{
				DateTimeFormatter formatter =DateTimeFormatter.ofPattern("dd/MM/yyyy");
				LocalDate date;
				LocalDate date1;
				
				while(true)
				{	
					System.out.println("enter date to check in(dd/MM/yyyy)");
					dateCheckIn=sc.next();
					if(hbvs.validateDateFormat(dateCheckIn))
					{
						date = LocalDate.parse(dateCheckIn, formatter);
						if(hbvs.validateDate(date))
							break;
						else
							System.out.println("Please enter a valid date");
					}
					else
						System.out.println("Invalid Input");
				}
				
				while(true)
				{
					System.out.println("enter date to check out(dd/MM/yyyy)");
					dateCheckOut=sc.next();
					if(hbvs.validateDateFormat(dateCheckOut))
					{
						date1 = LocalDate.parse(dateCheckOut, formatter);
						if(hbvs.validateCheckOutDate(date,date1))
							break;
						else
							System.out.println("Please enter a valid date");
					}
					else
						System.out.println("Invalid Input");
				}
				Period p = Period.between(date, date1);
				
				while(true)
				{
					System.out.println("enter no of adults");
					adult=sc.nextInt();
					System.out.println("enter no of children");
					children=sc.nextInt();
					int sum = adult+children;
					if(sum>3)
					{
						System.out.println("Total members cannot be more than 3!");
					}
					else
						break;
				}
				
				int day=p.getDays();
				cost=hbus.calculateCost(day,rid);
				System.out.println("cost is :"+cost);
			}
			else
			{
				System.out.println("Sorry!!!!No rooms available");
			}
			
			System.out.println("Do you confirm for yes press 1 else press any number for no");
			int res=sc.nextInt();
			
			if(res==1)
			{
				String booking_id=hbus.bookRoom(uid,dateCheckIn,dateCheckOut,adult,children,cost,hotelId,rid);	
				System.out.println(booking_id);
			}		
		} 
		catch (HotelBookingException e)
		{

			System.out.println(e.getMessage());
			bookHotel();
			
		}
	}
	
	
	
	public static void viewBookingDetails() 
	{
	
		hbus=new HotelBookingUserServiceImpl();
		hbvs=new HotelBookingValidationServiceImpl();
		System.out.println("***************Booking Status******************");
		ArrayList<BookingDetails> arr=new ArrayList<BookingDetails>();
		System.out.println("enter your booking id");
		int bid=sc.nextInt();
		try {
				arr=hbus.viewBookingStatus(bid);
				System.out.println("Booking id\tUser id\t\tBooked from\tBooked to\tAdults\tChildren\tAmount\tRoomId");
				for(BookingDetails ee:arr)
				{
					System.out.println(ee.getBooking_id()+"\t\t"+ee.getUser_id()+"\t\t"+ee.getBooked_from()+"\t"+ee.getBooked_to()+"\t"+ee.getNo_of_adults()+"\t"+ee.getNo_of_children()+"\t\t"+ee.getAmount()+"\t"+ee.getRoomId());
				}
		} 
		catch (HotelBookingException e) 
		{
			
			System.out.println(e.getMessage());
			viewBookingDetails();
		}
	}
	
	
	
	
	public static void viewBookingByDate() 
	{
		hbas=new HotelBookingAdminServiceImpl();
		hbvs=new HotelBookingValidationServiceImpl();
		System.out.println("************************************************");
		ArrayList<BookingDetails> bookList;
		try 
		{
			
			Date date = null;
			System.out.println("Enter date: ");
			String d=sc.next();
			date = new SimpleDateFormat("dd/MM/yyyy").parse(d);
			bookList = hbas.viewBookingByDate(date);
			System.out.println("\tBOOKING_ID \t\tHOTEL_ID \t\tUSER_ID \t\tBOOKED_FROM \t\tBOOKED_TO \t\tNO_OF_ADULTS \t\tNO_OF_CHILDREN \t\tAMOUNT");
			for(BookingDetails b:bookList)
			{
				System.out.println("\t"+b.getBooking_id() +"\t"+b.getHotel_id()+"\t"+b.getUser_id() +"\t"+b.getBooked_from()
								+"\t"+b.getBooked_to()+"\t"+b.getNo_of_adults()+"\t"+b.getNo_of_children()+"\t"+b.getAmount());
			}
			generateReport();
		} 
		catch (HotelBookingException | ParseException e)
		{
			System.out.println(e.getMessage());
			viewBookingByDate();
		}	
	}
	
	public static void viewBookingByHotel() 
	{
		hbas=new HotelBookingAdminServiceImpl();
		hbvs=new HotelBookingValidationServiceImpl();
		System.out.println("************************************************");
		int hotelId;
   	    System.out.println("\nEnter Hotel Id: ");
   	    hotelId=sc.nextInt();
		ArrayList<BookingDetails> bookList;
		try 
		{
			
			bookList = hbas.viewBookingByHotel(hotelId);
			System.out.println("\tBOOKING_ID \t\tHOTEL_ID \t\tUSER_ID \t\tBOOKED_FROM \t\tBOOKED_TO \t\tNO_OF_ADULTS \t\tNO_OF_CHILDREN \t\tAMOUNT");
			for(BookingDetails b:bookList)
			{
				System.out.println("\t"+b.getBooking_id() +"\t"+b.getHotel_id()+"\t"+b.getUser_id() +"\t"+b.getBooked_from()
									+"\t"+b.getBooked_to()+"\t"+b.getNo_of_adults()+"\t"+b.getNo_of_children()+"\t"+b.getAmount());
			}
			generateReport();
		} 
		catch (HotelBookingException e)
		{
			System.out.println(e.getMessage());
			viewBookingByHotel();
		}	
	}
     public static void viewGuestListOfHotel() 
     {
    	hbas=new HotelBookingAdminServiceImpl();
 		
 		System.out.println("************************************************");
    	 int hotelId;
    	 System.out.println("\nEnter Hotel Id: ");
    	 hotelId=sc.nextInt();
    	 ArrayList<BookingDetails> guestList;
 		try 
 		{
 			
 			guestList = hbas.viewGuestListOfHotel(hotelId);
 			System.out.println("\tBOOKING_ID \t\tHOTEL_ID \t\tUSER_ID \t\tBOOKED_FROM \t\tBOOKED_TO \t\tNO_OF_ADULTS \t\tNO_OF_CHILDREN \t\tAMOUNT");
 			for(BookingDetails b:guestList)
 			{
 				System.out.println("\t"+b.getBooking_id() +"\t\t"+b.getHotel_id()+"\t\t"+b.getUser_id() +"\t\t"+b.getBooked_from()
 									+"\t"+b.getBooked_to()+"\t"+b.getNo_of_adults()+"\t\t"+b.getNo_of_children()+"\t\t"+b.getAmount());
 			}
 			generateReport();
 		} 
 		catch (HotelBookingException e)
 		{
 			System.out.println(e.getMessage());
 			viewGuestListOfHotel();
 		}	
	 }
}