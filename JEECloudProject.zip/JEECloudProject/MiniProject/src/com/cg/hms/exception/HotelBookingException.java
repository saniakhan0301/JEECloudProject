 package com.cg.hms.exception;

public class HotelBookingException extends Exception 
{
	String msg;
	public HotelBookingException(String msg)
	{
		super(msg);
	}
	@Override
	public String toString() {
		return "HotelBookingException [error=" + msg + "]";
	}
	
	
}
