package com.cg.hms.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.hms.dto.BookingDetails;
import com.cg.hms.dto.Hotel;
import com.cg.hms.dto.RoomDetails;
import com.cg.hms.exception.HotelBookingException;
import com.cg.hms.util.DBUtil;


public class HotelBookingAdminDaoImpl implements HotelBookingAdminDao 
{
	Connection con=null;
	Statement st=null;
	public HotelBookingAdminDaoImpl()
	{
		
		PropertyConfigurator.configure("log4j.properties");
	}


	PreparedStatement pst=null;
	ResultSet rs=null;
	
	// Register a new User or admin
	
    //Login existing user or admin
	@Override
	public String login(int role,int userId, String password) throws HotelBookingException 
	{
		
		Logger myLogger=Logger.getLogger(HotelBookingAdminDaoImpl.class);
		String userPass="",username="";
		int userRole=0;
		try 
		{
			con=DBUtil.getConn();
			String query="SELECT * FROM USERS WHERE user_id=?";
			pst=con.prepareStatement(query);
			pst.setInt(1,userId);
			rs=pst.executeQuery();
			while(rs.next())
			{
				userPass=rs.getString("password");
				username=rs.getString("user_name");
				if(rs.getString("role").equals("Admin"))
					userRole=1;
			}
			if(userPass.equals(""))
				throw new HotelBookingException("Invalid user ID");
			else
			{
				if(userPass.equals(password))
				{
					if(role==userRole)
					{
						myLogger.info("User Logged in with id : "+userId);
						return username;
					}
					else
						throw new HotelBookingException("Password incorrect");
				}
					
					
				else
					throw new HotelBookingException("Password incorrect");
			
		    }
		
		}  
		catch (Exception e)
		{
		
			throw new HotelBookingException("Invalid UserID or Password");  
		}
		
	
	}
    //Add a new Hotel 
	@Override
	public int addHotel(Hotel hotel) throws HotelBookingException
	{
		Logger myLogger=Logger.getLogger(HotelBookingAdminDaoImpl.class);
		
		int hid=0;
		try 
		{
			con=DBUtil.getConn();
			String seqid1="select seq_hotel_id.nextVal from dual";
			st=con.createStatement();
			rs=st.executeQuery(seqid1);
			while(rs.next())	
			{
				hid=rs.getInt(1);	
			}
			String insertqry1="INSERT into hotel values(?,?,?,?,?,?,?,?,?,?,?)";
	
			pst=con.prepareStatement(insertqry1);
			pst.setInt(1,hid);
			pst.setString(2,hotel.getCity());
			pst.setString(3,hotel.getHotel_name());
			pst.setString(4,hotel.getAddress());
			pst.setString(5,hotel.getDescription());
			pst.setString(6,hotel.getCost());
			pst.setString(7,hotel.getPhno_no1());
			pst.setString(8,hotel.getPhno_no2());
			pst.setString(9,hotel.getRating());
			pst.setString(10,hotel.getEmail());
			pst.setString(11,hotel.getFax());
	        pst.execute();
	        myLogger.info("Hotel added with id :  "+hid);
			
		}
		catch(Exception e)
		{
			throw new HotelBookingException(e.getMessage());
		}
		return hid;
	}
    //Modify Description of the Hotel
	@Override
	public int modifyHotel(int hotelId,String description)throws HotelBookingException 
	{
		int data=0;
		Logger myLogger=Logger.getLogger(HotelBookingAdminDaoImpl.class);
		
		try{		
		    	try 
		    	{
		    		con=DBUtil.getConn();
		    	} 
		    	catch (IOException e) 
		    	{
		    		e.printStackTrace();
		    	}
		    	String updateqry="UPDATE hotel set description=? WHERE hotel_id=?";
		    	pst=con.prepareStatement(updateqry);
		    	pst.setString(1,description);
		    	pst.setInt(2,hotelId);
		    	data=pst.executeUpdate();
		    	myLogger.info("Hotel modified with id :  "+hotelId);
			}
			catch (SQLException e) 
        	{
				
				throw new HotelBookingException(e.getMessage());
        	}
		return data;
		
	}
    //Delete a Hotel
	@Override
	public int deleteHotel(int hotelId) throws HotelBookingException
	{
		Logger myLogger=Logger.getLogger(HotelBookingAdminDaoImpl.class);
		
		int data=0;
		try
		{ 
			con=DBUtil.getConn();
			String deleteqry1="DELETE FROM hotel WHERE hotel_id=?";
			pst=con.prepareStatement(deleteqry1);
			pst.setInt(1,hotelId);
			data=pst.executeUpdate();
			myLogger.info("Hotel deleted with id :  "+hotelId);	
		}
		catch(Exception e)
		{
			throw new HotelBookingException("Already booked unable to delete");
		} 
		finally 
		{
			try 
			{
				pst.close();
				con.close();
			}
			catch(SQLException e)
			{
				
				throw new HotelBookingException(e.getMessage());
			}
		}
		return data;
	}
    //Add a new Room
	@Override
	public int addRoom(RoomDetails room) throws HotelBookingException 
	{
		Logger myLogger=Logger.getLogger(HotelBookingAdminDaoImpl.class);
		
		int data=1;
		try
		{
			con=DBUtil.getConn();
			String query="insert into roomdetails values(?,?,?,?,?,?)";
			pst=con.prepareStatement(query);
			pst.setString(1,room.getHotel_id());
			pst.setString(2,room.getRoom_id());
			pst.setString(3,room.getRoom_type());
			pst.setFloat(4,room.getCost());
			pst.setString(5,room.getAvailability());
			pst.setString(6,room.getPhoto());
			pst.execute();
			
			
			//Select 
			float avgRate=0;
			String qry1="select * from hotel where hotel_id=?";
			pst=con.prepareStatement(qry1);
			pst.setString(1,room.getHotel_id() );
			rs=pst.executeQuery();
			while(rs.next())
			{
				avgRate=(Float.parseFloat(rs.getString("avg_rate_pernight"))+room.getCost())/2;
			}
			
			//Update Hotel Rate Per Night
			String qry2="Update hotel set avg_rate_pernight=? where hotel_id=?";
			pst=con.prepareStatement(qry2);
			pst.setFloat(1, avgRate);
			pst.setString(2,room.getHotel_id() );
			data=pst.executeUpdate();
			myLogger.info("room added hotel id :  "+room.getHotel_id()+" and room id : "+room.getRoom_id());
		}
		catch(Exception e)
		{
		
			throw new HotelBookingException("Unable to add Room details...");  
		}
		
		return data;
		
	}

	
    // Delete Room using Hotel ID by Admin
	@Override
	public int deleteRoom(String hotelId,String roomId) throws HotelBookingException
	{
		Logger myLogger=Logger.getLogger(HotelBookingAdminDaoImpl.class);
		
		int data;
		try{
			con=DBUtil.getConn();
			String query="delete from roomdetails where room_id=? and hotel_id=?";
			pst=con.prepareStatement(query);
			pst.setString(1,roomId);
			pst.setString(2,hotelId);
			pst.executeQuery();
			data=pst.executeUpdate();
			myLogger.info("room deleted hotel id :  "+hotelId+" and room id : "+roomId);
		}
		catch(Exception e)
		{
			
			throw new HotelBookingException("Unable to delete Room details...");  
		}
		return data;
		
	}
    //Booking Room by User
	
    
	

	
    
	// Show all Hotels
	@Override
	public ArrayList<Hotel> displayHotels() throws HotelBookingException 
	{
		ArrayList<Hotel> hList;
		try
		{
			hList = new ArrayList<Hotel>();
			con=DBUtil.getConn();
			String selectqry="SELECT * from Hotel";
			st=con.createStatement();
			rs=st.executeQuery(selectqry);
			while(rs.next())
			{
				hList.add(new Hotel(rs.getString("hotel_id"),
						rs.getString("city"),
						rs.getString("hotel_name"),
									rs.getString("address"),
									rs.getString("description"),
									rs.getString("avg_rate_pernight"),
									rs.getString("phone_no1"),
									rs.getString("phone_no2"),
									rs.getString("rating"),
									rs.getString("email"),
									rs.getString("fax")));
			}
		}
		catch(Exception e)
			{
				
				throw new HotelBookingException("Cannot be Displayed");
			}
		finally
		{
			try
			{
				st.close();
				rs.close();
				con.close();
			}
			catch(SQLException e)
			{
				
				throw new HotelBookingException(e.getMessage());
			}
		}
		return hList;
		
		
	}

	//Show booking details to Admin using Hotel ID
	@Override
	public ArrayList<BookingDetails> viewBookingByHotel(int hotelId)
			throws HotelBookingException 
	{
		ArrayList<BookingDetails> bookList;
		try
		{
			bookList = new ArrayList<BookingDetails>();
			con=DBUtil.getConn();
			String selectqry="SELECT * from BookingDetails WHERE hotel_id=?";
			pst=con.prepareStatement(selectqry);
			pst.setInt(1,hotelId);
			rs=pst.executeQuery();
			while(rs.next())
			{
				bookList.add(new BookingDetails(rs.getString("booking_id"),
												rs.getString("hotel_id"),
												rs.getString("user_id"),
												rs.getDate("booked_from"),
												rs.getDate("booked_to"),
												rs.getInt("no_of_adults"),
												rs.getInt("no_of_children"),
												rs.getFloat("amount"), rs.getString("roomId")));
			}
		}
		catch(Exception e)
			{
			
				throw new HotelBookingException("Cannot be Displayed");
			}
		finally
		{
			try
			{
				pst.close();
				rs.close();
				con.close();
			}
			catch(SQLException e)
			{
				
				throw new HotelBookingException(e.getMessage());
			}
		}
		return bookList;
	}

    // Details of users who are staying within the given dates	
	@Override
	public ArrayList<BookingDetails> viewGuestListOfHotel(int hotelId)
			throws HotelBookingException
	{
		ArrayList <BookingDetails> guestList;
		try
		{
			guestList = new ArrayList<BookingDetails>();
			con=DBUtil.getConn();
			LocalDate localDate = LocalDate.now();
			java.sql.Date date = java.sql.Date.valueOf(localDate); 
			String selectqry="SELECT * from BookingDetails WHERE hotel_id=? AND ?<=booked_to AND ?>=booked_from";
			pst=con.prepareStatement(selectqry);
			pst.setInt(1,hotelId);
			pst.setDate(2, date);
			pst.setDate(3,date);
			rs=pst.executeQuery();
			while(rs.next())
			{
				guestList.add(new BookingDetails(rs.getString("booking_id"),
						rs.getString("hotel_id"),
						rs.getString("user_id"),
						rs.getDate("booked_from"),
						rs.getDate("booked_to"),
						rs.getInt("no_of_adults"),
						rs.getInt("no_of_children"),
						rs.getFloat("amount"),rs.getString("roomId")));
			}
		}
		
	     catch(Exception e)
	    {
		  throw new HotelBookingException("Cannot be Displayed");
     	}
         finally
        {
 	      try
	    {
		  pst.close();
		  rs.close();
		  con.close();
	    }
	     catch(SQLException e)
	    {
		  
		  throw new HotelBookingException(e.getMessage());
	    }
        }
        return guestList;	
	}

	//View Bookings on particular date
	@Override
	public ArrayList<BookingDetails> viewBookingByDate(Date date)
			throws HotelBookingException 
	{
		ArrayList<BookingDetails> bookList;
		try
		{
			bookList = new ArrayList<BookingDetails>();
			con=DBUtil.getConn();
			java.sql.Date d11 = new java.sql.Date(date.getTime());
			String selectqry="SELECT * from BookingDetails WHERE booked_from=?";
			pst=con.prepareStatement(selectqry);
			pst.setDate(1,d11);
			rs=pst.executeQuery();
			while(rs.next())
			{
				bookList.add(new BookingDetails(rs.getString("booking_id"),
									rs.getString("hotel_id"),
									rs.getString("user_id"),
									rs.getDate("booked_from"),
									rs.getDate("booked_to"),
									rs.getInt("no_of_adults"),
									rs.getInt("no_of_children"),
									rs.getFloat("amount"),rs.getString("roomId")));
			}
		}
		catch(Exception e)
			{
				
				throw new HotelBookingException("Cannot be Displayed");
			}
		finally
		{
			try
			{
				pst.close();
				rs.close();
				con.close();
			}
			catch(SQLException e)
			{
				throw new HotelBookingException(e.getMessage());
			}
		}
		return bookList;	
	
	}
    
   
    //Display Hotel in a particular City
	@Override
	public ArrayList<Hotel> displayHotelByCity(String city)
			throws HotelBookingException 
	{
		ArrayList<Hotel> hList;
		try
		{
			hList = new ArrayList<Hotel>();
			con=DBUtil.getConn();
			String selectqry="SELECT * from Hotel where city=?";
			pst=con.prepareStatement(selectqry);
			pst.setString(1, city);
			rs=pst.executeQuery();
			while(rs.next())
			{
				hList.add(new Hotel(rs.getString("hotel_id"),
						rs.getString("city"),
						rs.getString("hotel_name"),
									rs.getString("address"),
									rs.getString("description"),
									rs.getString("avg_rate_pernight"),
									rs.getString("phone_no1"),
									rs.getString("phone_no2"),
									rs.getString("rating"),
									rs.getString("email"),
									rs.getString("fax")));
			}
		}
		catch(Exception e)
			{
				
				throw new HotelBookingException("Cannot be Displayed");
			}
		finally
		{
			try
			{
				pst.close();
				rs.close();
				con.close();
			}
			catch(SQLException e)
			{
				throw new HotelBookingException(e.getMessage());
			}
		}
		return hList;
		
	}

	
}
