package com.cg.hms.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.hms.dto.BookingDetails;
import com.cg.hms.dto.Hotel;
import com.cg.hms.dto.RoomDetails;
import com.cg.hms.dto.User;
import com.cg.hms.exception.HotelBookingException;
import com.cg.hms.util.DBUtil;



public class HotelBookingUserDaoImpl implements HotelBookingUserDao 
{

	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	
	public HotelBookingUserDaoImpl()
	{
		
		PropertyConfigurator.configure("log4j.properties");
	}
	@Override
	public int register(User user) throws HotelBookingException 
	{
		Logger myLogger=Logger.getLogger(HotelBookingAdminDaoImpl.class);
		
		
        int uid=0;
		try 
		{
			con=DBUtil.getConn();
			String seqid="select seq_user_id.nextVal from dual";
			st=con.createStatement();
			rs=st.executeQuery(seqid);
			while(rs.next())	
			{
				uid=rs.getInt(1);	
			}
			String insertqry="INSERT  Users values(?,?,?,?,?,?,?,?)";
	
			pst=con.prepareStatement(insertqry);
			pst.setInt(1,uid);
			pst.setString(2,user.getPassword());
			pst.setString(3,user.getRole());
			pst.setString(4,user.getUser_name());
			pst.setString(5,user.getMob_no());
			pst.setString(6,user.getPhone());
			pst.setString(7,user.getAddress());
			pst.setString(8,user.getEmail());
			pst.execute();
			myLogger.info("User data inserted : "+uid);
		}
		catch(Exception e)
		{
			throw new HotelBookingException(e.getMessage());
		}
		return uid;
		
		
		
	}

	@Override
	public String login(int role,int userId, String password) throws HotelBookingException 
	{
		Logger myLogger=Logger.getLogger(HotelBookingAdminDaoImpl.class);
		
		String userPass="",username="";
		int userRole=0;
		try 
		{
			con=DBUtil.getConn();
			String query="SELECT * FROM USERS WHERE user_id=?";
			pst=con.prepareStatement(query);
			pst.setInt(1,userId);
			rs=pst.executeQuery();
			while(rs.next())
			{
				userPass=rs.getString("password");
				username=rs.getString("user_name");
				if(rs.getString("role").equals("Admin"))
					userRole=1;
			}
			if(userPass.equals(""))
				throw new HotelBookingException("Invalid user ID");
			else
			{
				if(userPass.equals(password))
				{
					if(role==userRole)
					{
						myLogger.info("User Logged in with id : "+userId);
						return username;
					}
					else
						throw new HotelBookingException("Password incorrect");
				}
					
					
				else
					throw new HotelBookingException("Password incorrect");
			
		    }
		
		}  
		catch (Exception e)
		{
			
			throw new HotelBookingException("Invalid UserID or Password");  
		}
		
	
	}

	@Override
	public String bookRoom(String uid,String dateCheckIn, String dateCheckOut, int adult, int children, float cost,String hotelId,String roomId)throws HotelBookingException
	{
		
		Logger myLogger=Logger.getLogger(HotelBookingAdminDaoImpl.class);
		
		String availability="";
		try {
			
			con=DBUtil.getConn();
			String seqid="select seq_book_id.nextVal from dual";
			st=con.createStatement();
			rs=st.executeQuery(seqid);
			int bid=0;
			while(rs.next())	
			{
				bid=rs.getInt(1);	
			}
			String bookingId=Integer.toString(bid);
			Date	d1 = new SimpleDateFormat("dd/MM/yyyy").parse(dateCheckIn);
			java.sql.Date d11 = new java.sql.Date(d1.getTime());
		 
			Date	d2=new SimpleDateFormat("dd/MM/yyyy").parse(dateCheckOut);
			java.sql.Date d12 = new java.sql.Date(d2.getTime());
		
			String qry="Insert into bookingdetails values(?,?,?,?,?,?,?,?,?)";	
			con=DBUtil.getConn();
			pst=con.prepareStatement(qry);
			pst.setString(1,bookingId);
			pst.setString(2,uid);
			pst.setDate(3,d11);
			pst.setDate(4,d12);
			pst.setInt(5,adult);
			pst.setInt(6,children);
			pst.setDouble(7,cost);
			pst.setString(8, hotelId);
			pst.setString(9, roomId);
		
			int aff=pst.executeUpdate();
			
			if(aff!=0)
			{
				System.out.println("successfully booked!!!");
				String qry1="select availability from roomDetails where room_id=?";
				pst=con.prepareStatement(qry1);
				pst.setString(1, roomId);
				rs=pst.executeQuery();
				while(rs.next())
				{
					availability=rs.getString("availability");
				}
				int avail=Integer.parseInt(availability);
				avail=avail-1;
				String avail1=(Integer.toString(avail));
				
				
		        //Update Rooom Details after successful booking		
				String qry2="Update roomdetails set availability=? where room_id=?";
				pst=con.prepareStatement(qry2);
				pst.setString(1, avail1);
				pst.setString(2, roomId);
				int data=pst.executeUpdate();
				myLogger.info("user : "+uid+" booked room with booking id : "+bookingId);
				return bookingId;
				
			}
			else
			{
				throw new HotelBookingException("Booking Failed");
				
			}
		}
		 catch (Exception e)
		{
			
			throw new HotelBookingException("Booking Failed");
		}
	
	
	}

	//Show the Booking Details to User using Booking ID
		@Override
		public ArrayList<BookingDetails> viewBookingStatus(int bookingId)
				throws HotelBookingException 
		{
			ArrayList<BookingDetails> arr=new ArrayList<BookingDetails>();
			String qry="select * from bookingdetails where booking_Id=?";
			String availability=Integer.toString(bookingId);
			try
			{
				con=DBUtil.getConn();
				pst=con.prepareStatement(qry);
				pst.setString(1, availability);
				rs=pst.executeQuery();
				while(rs.next())
				{
					arr.add(new BookingDetails(availability,rs.getString("hotel_id"),rs.getString("user_id"),rs.getDate("booked_from"),rs.getDate("booked_to"),rs.getInt("no_of_adults"),rs.getInt("no_of_children"),rs.getFloat("amount"), rs.getString("roomId")));
				}
			} 
			catch (IOException|SQLException e) 
			{
			
				throw new HotelBookingException("Unable to show boooking status");
			}
			return arr;
		}
		// Show all the rooms details through Hotel ID
		@Override
		public ArrayList<RoomDetails> searchRoom(int hotelId)
				throws HotelBookingException
		{
			ArrayList<RoomDetails> searchList;
			try
			{
				con=DBUtil.getConn();
				searchList = new ArrayList<RoomDetails>();
				String selectqry="SELECT * FROM RoomDetails WHERE hotel_id = ?";
				pst=con.prepareStatement(selectqry);
				pst.setInt(1,hotelId);
				rs=pst.executeQuery();
				
			while(rs.next())
			{
				searchList.add(new RoomDetails(rs.getString("hotel_id"), rs.getString("room_id"),
						rs.getString("room_type"),rs.getFloat("cost"), rs.getString("availability"),
						rs.getString("photo")));
			}
			}
			catch(Exception e)
			{
				
				throw new HotelBookingException("Does Not Exist");
			}
			return searchList;
			
		}
		

	//Check Availability of Room in a particular Hotel
		@Override
		public Boolean checkAvailability(String hotelId, String typeOfRoom) throws HotelBookingException 
		{
			String availability="";
			String qry="select * from roomDetails where hotel_id=? and room_type=? ";
			try {
			
					con=DBUtil.getConn();
				
				pst=con.prepareStatement(qry);
			
			
			
			pst.setString(1,hotelId);
			pst.setString(2, typeOfRoom);
			rs=pst.executeQuery();
			while(rs.next())
			{
				availability=rs.getString("availability");
			}
			
			
			} 
			catch (IOException|SQLException e) 
			{
				
				throw new HotelBookingException("Not Available");
			}
			if(availability.equals("0"))
			{
				return false;
			}
			else
			{
				return true;
				
			}
			
		}

		//Calculate total cost of stay
		@Override
		public float calculateCost(int day,String rid) throws HotelBookingException
		{	String price="0";
			float cost=0;
			String qry="Select per_night_rate from roomdetails where room_id=? ";
			try {
				con=DBUtil.getConn();
			
				
			
			pst=con.prepareStatement(qry);
			pst.setString(1, rid);
			rs=pst.executeQuery();
			while(rs.next())
			{
				price=rs.getString("per_night_rate");
			}
			}
			catch (IOException|SQLException e) {
				
				throw new HotelBookingException("Something went wrong please try again");
			}
			int price1=Integer.parseInt(price);
			cost=(float)day*price1;
			return cost;
			
		}

		 //Display Rooms of given Hotel ID
		@Override
		public ArrayList<RoomDetails> displayRooms(String hotelId)
				throws HotelBookingException {
			ArrayList<RoomDetails> arrl=new ArrayList<RoomDetails>();
			String qry="select * from roomdetails where hotel_id=?";
			
				try {
					con=DBUtil.getConn();
				
				pst=con.prepareStatement(qry);
				pst.setString(1, hotelId);
				rs=pst.executeQuery();
				while(rs.next())
				{
					arrl.add(new RoomDetails(hotelId, rs.getString("room_id"), rs.getString("room_type"), rs.getFloat("per_night_rate"), rs.getString("availability"), null));
				}
				
			} 
			catch (IOException|SQLException e)
			{
				
				throw new HotelBookingException("Cannot Be Displayed");
			}
				return arrl;
		}
		

		 //Display Hotel in a particular City
		@Override
		public ArrayList<Hotel> displayHotelByCity(String city)
				throws HotelBookingException 
		{
			ArrayList<Hotel> hList;
			try
			{
				hList = new ArrayList<Hotel>();
				con=DBUtil.getConn();
				String selectqry="SELECT * from Hotel where city=?";
				pst=con.prepareStatement(selectqry);
				pst.setString(1, city);
				rs=pst.executeQuery();
				while(rs.next())
				{
					hList.add(new Hotel(rs.getString("hotel_id"),
							rs.getString("city"),
							rs.getString("hotel_name"),
										rs.getString("address"),
										rs.getString("description"),
										rs.getString("avg_rate_pernight"),
										rs.getString("phone_no1"),
										rs.getString("phone_no2"),
										rs.getString("rating"),
										rs.getString("email"),
										rs.getString("fax")));
				}
			}
			catch(Exception e)
				{
					
					throw new HotelBookingException("Error");
				}
			finally
			{
				try
				{
					pst.close();
					rs.close();
					con.close();
				}
				catch(SQLException e)
				{
					
					throw new HotelBookingException(e.getMessage());
				}
			}
			return hList;
			
		}

	
}