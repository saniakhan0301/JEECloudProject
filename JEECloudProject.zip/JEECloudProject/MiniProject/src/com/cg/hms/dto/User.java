package com.cg.hms.dto;
public class User 
{
	private int  userId;
	private String	password;
	private String	role;
	private String	userName;
	private String	mobNo;
	private String	phone;
	private String	address;
	private String	email;
		
	public User() 
	{
			
	}
	
	public User(int userId, String password, String role, String userName, String mobNo, String phone,
				String address, String email) 
	{
			
			this.userId = userId;
			this.password = password;
			this.role = role;
			this.userName = userName;
			this.mobNo = mobNo;
			this.phone = phone;
			this.address = address;
			this.email = email;
	}
	
	public int getUser_id()
	{
			return userId;
	}
		
	public void setUser_id(int userId) 
	{
			this.userId = userId;
	}
	
	public String getPassword() 
	{
			return password;
	}
	
	public void setPassword(String password) 
	{
			this.password = password;
	}
	
	public String getRole() 
	{
			return role;
	}
	
	public void setRole(String role) 
	{
			this.role = role;
	}
		
	public String getUser_name() 
	{
			return userName;
	}
	
	public void setUser_name(String userName) 
	{
			this.userName = userName;
	}
		
	public String getMob_no() 
	{
			return mobNo;
		
	}
		
	public void setMob_no(String mobNo)
	{
			this.mobNo = mobNo;
	}
		
	public String getPhone()
	{
			return phone;
		
	}
		
	public void setPhone(String phone) 
	{
			this.phone = phone;
	}
	
	public String getAddress()
	{
			return address;
	}
	
	public void setAddress(String address)
	{
			this.address = address;
	}
	
	public String getEmail() 
	{
			return email;
		
	}
		
	public void setEmail(String email) 
	{
			this.email = email;
		
	}
	
	@Override
	public String toString() 
	{
			return "User [user_id=" + userId + ", password=" + password + ", role=" + role + ", user_name=" + userName
					+ ", mob_no=" + mobNo + ", phone=" + phone + ", address=" + address + ", email=" + email + "]";
	}
		
	
	}
