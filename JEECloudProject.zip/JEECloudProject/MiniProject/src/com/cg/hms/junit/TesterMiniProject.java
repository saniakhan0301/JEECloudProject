package com.cg.hms.junit;

import java.util.regex.Pattern;

import junit.framework.Assert;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.hms.dao.HotelBookingAdminDao;
import com.cg.hms.dao.HotelBookingAdminDaoImpl;
import com.cg.hms.dao.HotelBookingUserDao;
import com.cg.hms.dao.HotelBookingUserDaoImpl;
import com.cg.hms.exception.HotelBookingException;



public class TesterMiniProject
{
	
	static HotelBookingAdminDao service=null;
	static HotelBookingUserDao service1=null;
	
	@BeforeClass
	public static void setUp()
	{
		service=new HotelBookingAdminDaoImpl();
		service1=new HotelBookingUserDaoImpl();
	
	}
	
  
  @Test
  public void login()
  {
	try
	{
			
		Assert.assertEquals("Swati",service.login(1, 101, "Admin@123"));
	} 
	catch (HotelBookingException e)
	{
			e.printStackTrace();
	}
	  
	
  }
  @Test(expected=HotelBookingException.class)
  public void login1() throws HotelBookingException
  {
	
	
		service.login(1, 123, "Admin@123");
	 
	
  }
  @Test
  public void modifyHotelDetails1()
  {
	
	
	  try
		{
				
			Assert.assertEquals(0,service.modifyHotel(191, "Normal"));
		} 
		catch (HotelBookingException e)
		{
				e.printStackTrace();
		}
	 
	
  }
  @Test
  public void modifyHotelDetails()
  {
	try
	{
			
		Assert.assertEquals(1,service.modifyHotel(141, "Normal"));
	} 
	catch (HotelBookingException e)
	{
			e.printStackTrace();
	}
	  
	
  }
  @Test
  public void bookRoom()
  {
	try
	{
		String Pattern1="[0-9]+[0-9]+[0-9]";
		String bookingId=service1.bookRoom("222","20/10/2018","21/10/2018",1,0,1000.0f,"161","111");
		Assert.assertTrue(Pattern.matches(Pattern1, bookingId));
	} 
	catch (HotelBookingException e)
	{
			e.printStackTrace();
	}
	  
	
  }

}
