package com.example.RailwayReservationSystem_157794;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class RailwayReservationSystem157794Application {

	public static void main(String[] args)
	{
		SpringApplication.run(RailwayReservationSystem157794Application.class, args);
	}
}
