package com.example.RailwayReservationSystem_157794;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CustomResponse {

List<Client>lc;

public List<Client> getLc() {
	return lc;
}

public void setLc(List<Client> lc) {
	this.lc = lc;
}




}
