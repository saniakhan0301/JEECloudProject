package com.example.RailwayReservationSystem_157794;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class ReservationController 
{
	@Autowired
	IReservationService service;
	
	@PostMapping("/insert")                         //Inserts Client object in collection 
	public String insert(@RequestBody Client r)
	{
		service.save(r);
		return "SUCCESS";
	}
	@PostMapping("/insertAll")                     //Inserts Array of Client objects in collection
	public String insertAll(@RequestBody List<Client> r)
	{
		service.saveAll(r);
		return "SUCCESS";
	}
	@GetMapping("/user/{pnrno}")            //retreives Client object based on pnrno
	public Client retreive(@PathVariable("pnrno") String pnrno)
	{
		try
		{
			Client r=service.findById(pnrno).get();
			if(r==null)
				throw new MyException("PNR Not Found wrong PnrNo : "+pnrno);
			return r;
		}
		catch(Exception e)
		{
			throw new MyException("PNR Not Found wrong PnrNo : "+pnrno);   //throws user defined exception when client does not found with pnrno defined
		}
		
	}
	@GetMapping(value="/retrieveAll",produces=MediaType.APPLICATION_XML_VALUE)            //retrieves all client objects stored in reservation collection
	public CustomResponse  retreiveAll()
	{
		List<Client> l= service.findAll();
		System.out.println();
		
		CustomResponse c=new CustomResponse();
		c.setLc(l);
		
		return c;
	}
}
