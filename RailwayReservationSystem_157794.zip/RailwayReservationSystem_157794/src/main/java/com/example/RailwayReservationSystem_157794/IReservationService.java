package com.example.RailwayReservationSystem_157794;


import org.springframework.data.mongodb.repository.MongoRepository;




//Interface extends MongoRepository

public interface IReservationService extends MongoRepository<Client, String> 
{

	
}
