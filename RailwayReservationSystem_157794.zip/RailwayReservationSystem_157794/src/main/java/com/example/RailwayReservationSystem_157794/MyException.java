package com.example.RailwayReservationSystem_157794;

import org.springframework.web.bind.annotation.ResponseStatus;

public class MyException extends RuntimeException {
	 
   String message;
 
    public MyException(String message) {
        super(message);
        this.message=message;
    }
}